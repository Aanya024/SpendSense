import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { LayoutDashboard, Receipt, CreditCard, MessageSquare, TrendingUp, Menu, X, Plus, Users } from 'lucide-react';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import TransactionList from './components/TransactionList';
import SubscriptionTracker from './components/SubscriptionTracker';
import Chatbot from './components/Chatbot';
import PredictiveBudget from './components/PredictiveBudget';
import BillSplitter from './components/BillSplitter';
import { Button } from './components/ui/button';
import { toast, Toaster } from 'sonner';

interface BudgetCategory {
  name: string;
  amount: number;
  icon: string;
}

interface Transaction {
  id: string;
  vendor: string;
  amount: number;
  category: string;
  date: Date;
  aiParsed: boolean;
  rawText?: string;
}

interface Subscription {
  id: string;
  name: string;
  amount: number;
  renewalDate: Date;
  status: 'active' | 'paused';
  icon: string;
}

interface Friend {
  id: string;
  name: string;
  avatar: string;
}

interface SplitExpense {
  id: string;
  description: string;
  totalAmount: number;
  paidBy: string;
  date: Date;
  participants: {
    id: string;
    name: string;
    amount: number;
    settled: boolean;
  }[];
  category: string;
}

export default function App() {
  const [isOnboarded, setIsOnboarded] = useState(false);
  const [budgets, setBudgets] = useState<BudgetCategory[]>([]);
  const [totalIncome, setTotalIncome] = useState(5000);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [splitExpenses, setSplitExpenses] = useState<SplitExpense[]>([]);
  const [activeView, setActiveView] = useState<'dashboard' | 'transactions' | 'subscriptions' | 'chat' | 'forecast' | 'split'>('dashboard');
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('spendsense-data');
    if (stored) {
      const data = JSON.parse(stored);
      setIsOnboarded(data.isOnboarded);
      setBudgets(data.budgets || []);
      setTotalIncome(data.totalIncome || 5000);
      setTransactions(data.transactions?.map((t: any) => ({ ...t, date: new Date(t.date) })) || []);
      setSubscriptions(data.subscriptions?.map((s: any) => ({ ...s, renewalDate: new Date(s.renewalDate) })) || []);
      setFriends(data.friends || []);
      setSplitExpenses(data.splitExpenses?.map((e: any) => ({ ...e, date: new Date(e.date) })) || []);
    } else {
      loadSampleData();
    }
  }, []);

  useEffect(() => {
    if (isOnboarded) {
      localStorage.setItem('spendsense-data', JSON.stringify({
        isOnboarded,
        budgets,
        totalIncome,
        transactions,
        subscriptions,
        friends,
        splitExpenses
      }));
    }
  }, [isOnboarded, budgets, totalIncome, transactions, subscriptions, friends, splitExpenses]);

  const loadSampleData = () => {
    const sampleTransactions: Transaction[] = [
      {
        id: '1',
        vendor: 'Zomato',
        amount: 250,
        category: 'Food',
        date: new Date(2026, 3, 8, 13, 30),
        aiParsed: true,
        rawText: 'Your order from Pizza Hut via Zomato for Rs.250 has been delivered'
      },
      {
        id: '2',
        vendor: 'Uber',
        amount: 120,
        category: 'Transport',
        date: new Date(2026, 3, 7, 9, 15),
        aiParsed: true,
        rawText: 'You paid Rs.120 for your Uber ride to MG Road'
      },
      {
        id: '3',
        vendor: 'BookMyShow',
        amount: 300,
        category: 'Entertainment',
        date: new Date(2026, 3, 6, 18, 45),
        aiParsed: true,
        rawText: 'Booking confirmed! 2 tickets for Avengers at PVR Cinemas - Rs.300'
      },
      {
        id: '4',
        vendor: 'Amazon',
        amount: 450,
        category: 'Shopping',
        date: new Date(2026, 3, 5, 14, 20),
        aiParsed: false
      },
      {
        id: '5',
        vendor: 'Swiggy',
        amount: 180,
        category: 'Food',
        date: new Date(2026, 3, 5, 20, 10),
        aiParsed: true,
        rawText: 'Swiggy: Your order from Dominos Rs.180 will be delivered by 8:30 PM'
      },
      {
        id: '6',
        vendor: 'Metro Card',
        amount: 50,
        category: 'Transport',
        date: new Date(2026, 3, 4, 8, 0),
        aiParsed: true,
        rawText: 'Metro card recharge successful - Rs.50 debited from your account'
      },
      {
        id: '7',
        vendor: 'Cafe Coffee Day',
        amount: 200,
        category: 'Food',
        date: new Date(2026, 3, 3, 16, 30),
        aiParsed: false
      },
      {
        id: '8',
        vendor: 'Flipkart',
        amount: 350,
        category: 'Shopping',
        date: new Date(2026, 3, 2, 11, 45),
        aiParsed: true,
        rawText: 'Your Flipkart order #FK2134 for Rs.350 has been dispatched'
      }
    ];

    const sampleSubscriptions: Subscription[] = [
      {
        id: '1',
        name: 'Netflix',
        amount: 199,
        renewalDate: new Date(2026, 3, 15),
        status: 'active',
        icon: '🎬'
      },
      {
        id: '2',
        name: 'Spotify',
        amount: 119,
        renewalDate: new Date(2026, 3, 20),
        status: 'active',
        icon: '🎵'
      },
      {
        id: '3',
        name: 'Amazon Prime',
        amount: 129,
        renewalDate: new Date(2026, 3, 10),
        status: 'active',
        icon: '📦'
      },
      {
        id: '4',
        name: 'YouTube Premium',
        amount: 89,
        renewalDate: new Date(2026, 4, 5),
        status: 'paused',
        icon: '📺'
      }
    ];

    const sampleFriends: Friend[] = [
      { id: '1', name: 'Rahul', avatar: 'R' },
      { id: '2', name: 'Priya', avatar: 'P' },
      { id: '3', name: 'Amit', avatar: 'A' },
      { id: '4', name: 'Neha', avatar: 'N' }
    ];

    const sampleSplitExpenses: SplitExpense[] = [
      {
        id: '1',
        description: 'Dinner at Pizza Hut',
        totalAmount: 800,
        paidBy: 'You',
        date: new Date(2026, 3, 8, 20, 30),
        category: 'Split',
        participants: [
          { id: 'you', name: 'You', amount: 200, settled: false },
          { id: '1', name: 'Rahul', amount: 200, settled: false },
          { id: '2', name: 'Priya', amount: 200, settled: true },
          { id: '3', name: 'Amit', amount: 200, settled: false }
        ]
      },
      {
        id: '2',
        description: 'Uber to College',
        totalAmount: 150,
        paidBy: 'Rahul',
        date: new Date(2026, 3, 7, 8, 15),
        category: 'Split',
        participants: [
          { id: 'you', name: 'You', amount: 50, settled: false },
          { id: '1', name: 'Rahul', amount: 50, settled: false },
          { id: '4', name: 'Neha', amount: 50, settled: true }
        ]
      },
      {
        id: '3',
        description: 'Movie Tickets',
        totalAmount: 600,
        paidBy: 'Priya',
        date: new Date(2026, 3, 6, 18, 0),
        category: 'Split',
        participants: [
          { id: 'you', name: 'You', amount: 150, settled: true },
          { id: '2', name: 'Priya', amount: 150, settled: false },
          { id: '1', name: 'Rahul', amount: 150, settled: false },
          { id: '3', name: 'Amit', amount: 150, settled: false }
        ]
      }
    ];

    setTransactions(sampleTransactions);
    setSubscriptions(sampleSubscriptions);
    setFriends(sampleFriends);
    setSplitExpenses(sampleSplitExpenses);
  };

  const handleOnboardingComplete = (newBudgets: BudgetCategory[]) => {
    setBudgets(newBudgets);
    setIsOnboarded(true);
    toast.success('Welcome to SpendSense! Your AI assistant is ready.', {
      description: 'Start tracking your expenses automatically',
    });
  };

  const handlePauseSubscription = (id: string) => {
    setSubscriptions(prev =>
      prev.map(sub => sub.id === id ? { ...sub, status: 'paused' as const } : sub)
    );
    toast.success('Subscription paused', {
      description: "You won't be charged next billing cycle",
    });
  };

  const handleResumeSubscription = (id: string) => {
    setSubscriptions(prev =>
      prev.map(sub => sub.id === id ? { ...sub, status: 'active' as const } : sub)
    );
    toast.success('Subscription resumed');
  };

  const handleCancelSubscription = (id: string) => {
    const sub = subscriptions.find(s => s.id === id);
    setSubscriptions(prev => prev.filter(s => s.id !== id));
    toast.success(`${sub?.name} subscription cancelled`);
  };

  const handleAddFriend = (name: string) => {
    const newFriend: Friend = {
      id: Date.now().toString(),
      name,
      avatar: name.charAt(0)
    };
    setFriends(prev => [...prev, newFriend]);
  };

  const handleAddSplitExpense = (expense: Omit<SplitExpense, 'id' | 'date'>) => {
    const newExpense: SplitExpense = {
      ...expense,
      id: Date.now().toString(),
      date: new Date()
    };
    setSplitExpenses(prev => [newExpense, ...prev]);
  };

  const handleSettleUp = (expenseId: string, participantId: string) => {
    setSplitExpenses(prev =>
      prev.map(expense =>
        expense.id === expenseId
          ? {
              ...expense,
              participants: expense.participants.map(p =>
                p.id === participantId ? { ...p, settled: true } : p
              )
            }
          : expense
      )
    );
  };

  const addTransaction = () => {
    const vendors = ['Starbucks', 'McDonald\'s', 'Ola', 'Myntra', 'BigBasket'];
    const categories = ['Food', 'Transport', 'Shopping', 'Entertainment', 'Other'];
    const randomVendor = vendors[Math.floor(Math.random() * vendors.length)];
    const randomCategory = categories[Math.floor(Math.random() * categories.length)];
    const randomAmount = Math.floor(Math.random() * 500) + 50;

    const newTransaction: Transaction = {
      id: Date.now().toString(),
      vendor: randomVendor,
      amount: randomAmount,
      category: randomCategory,
      date: new Date(),
      aiParsed: true,
      rawText: `Payment of Rs.${randomAmount} to ${randomVendor} via UPI`
    };

    setTransactions(prev => [newTransaction, ...prev]);
    toast.success('Transaction added by AI', {
      description: `₹${randomAmount} at ${randomVendor} - ${randomCategory}`,
    });

    const budget = budgets.find(b => b.name === randomCategory);
    const spent = transactions.filter(t => t.category === randomCategory).reduce((sum, t) => sum + t.amount, 0) + randomAmount;
    if (budget && spent > budget.amount * 0.9) {
      setTimeout(() => {
        toast.error('Budget Alert', {
          description: `You're nearing your ${randomCategory} budget limit!`,
        });
      }, 1000);
    }
  };

  if (!isOnboarded) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  const navItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'forecast' as const, label: 'AI Forecast', icon: TrendingUp },
    { id: 'transactions' as const, label: 'Transactions', icon: Receipt },
    { id: 'split' as const, label: 'Bill Splitter', icon: Users },
    { id: 'subscriptions' as const, label: 'Subscriptions', icon: CreditCard },
    { id: 'chat' as const, label: 'AI Chat', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row" style={{ background: 'var(--background)' }}>
      <Toaster position="top-center" />

      <motion.div
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        className={`${
          menuOpen ? 'block' : 'hidden'
        } md:block fixed md:relative inset-0 md:inset-auto z-50 md:z-auto w-64 flex-shrink-0`}
        style={{ background: 'var(--card)' }}
      >
        <div className="p-6 border-b md:border-b-0" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-between md:justify-start gap-3">
            <div>
              <h1 className="text-2xl font-bold" style={{ color: 'var(--primary)' }}>SpendSense</h1>
              <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Stop Financial Leaking</p>
            </div>
            <button
              onClick={() => setMenuOpen(false)}
              className="md:hidden p-2"
              style={{ color: 'var(--foreground)' }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <nav className="p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id);
                  setMenuOpen(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all"
                style={{
                  background: activeView === item.id ? 'var(--primary)' : 'transparent',
                  color: activeView === item.id ? 'var(--primary-foreground)' : 'var(--foreground)',
                }}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t" style={{ borderColor: 'var(--border)' }}>
          <Button
            onClick={addTransaction}
            className="w-full"
            style={{ background: 'var(--secondary)', color: 'var(--secondary-foreground)' }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Simulate Transaction
          </Button>
        </div>
      </motion.div>

      {menuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setMenuOpen(false)}
        />
      )}

      <div className="flex-1 flex flex-col min-h-screen">
        <div className="md:hidden flex items-center justify-between p-4 border-b" style={{ borderColor: 'var(--border)' }}>
          <button onClick={() => setMenuOpen(true)} style={{ color: 'var(--foreground)' }}>
            <Menu className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold" style={{ color: 'var(--primary)' }}>SpendSense</h1>
          <div className="w-6" />
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="max-w-6xl mx-auto p-4 md:p-8">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {activeView === 'dashboard' && (
                <Dashboard budgets={budgets} transactions={transactions} totalIncome={totalIncome} />
              )}
              {activeView === 'forecast' && (
                <PredictiveBudget budgets={budgets} transactions={transactions} totalIncome={totalIncome} />
              )}
              {activeView === 'transactions' && <TransactionList transactions={transactions} />}
              {activeView === 'split' && (
                <BillSplitter
                  friends={friends}
                  splitExpenses={splitExpenses}
                  onAddFriend={handleAddFriend}
                  onAddExpense={handleAddSplitExpense}
                  onSettleUp={handleSettleUp}
                />
              )}
              {activeView === 'subscriptions' && (
                <SubscriptionTracker
                  subscriptions={subscriptions}
                  onPause={handlePauseSubscription}
                  onResume={handleResumeSubscription}
                  onCancel={handleCancelSubscription}
                />
              )}
              {activeView === 'chat' && (
                <div className="rounded-lg p-6 h-[calc(100vh-12rem)]" style={{ background: 'var(--card)' }}>
                  <Chatbot transactions={transactions} budgets={budgets} totalIncome={totalIncome} />
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}