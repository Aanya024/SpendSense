import { useState } from 'react';
import { motion } from 'motion/react';
import { Wallet, TrendingUp, Calculator, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface BudgetCategory {
  name: string;
  amount: number;
  icon: string;
}

interface OnboardingProps {
  onComplete: (budgets: BudgetCategory[]) => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [monthlyIncome, setMonthlyIncome] = useState('');
  const [budgets, setBudgets] = useState<BudgetCategory[]>([
    { name: 'Food', amount: 0, icon: '🍔' },
    { name: 'Transport', amount: 0, icon: '🚌' },
    { name: 'Entertainment', amount: 0, icon: '🎬' },
    { name: 'Shopping', amount: 0, icon: '🛍️' },
    { name: 'Other', amount: 0, icon: '📦' },
  ]);

  const handleBudgetChange = (index: number, value: string) => {
    const newBudgets = [...budgets];
    newBudgets[index].amount = parseFloat(value) || 0;
    setBudgets(newBudgets);
  };

  const totalBudget = budgets.reduce((sum, b) => sum + b.amount, 0);
  const remaining = parseFloat(monthlyIncome) - totalBudget;

  const handleNext = () => {
    if (step === 0 && monthlyIncome) {
      setStep(1);
    } else if (step === 1) {
      onComplete(budgets);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--background)' }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-2xl"
      >
        {step === 0 && (
          <div className="space-y-8">
            <div className="text-center space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring' }}
              >
                <Wallet className="w-20 h-20 mx-auto" style={{ color: 'var(--primary)' }} />
              </motion.div>
              <h1 className="text-4xl font-bold" style={{ color: 'var(--foreground)' }}>
                Welcome to SpendSense
              </h1>
              <p className="text-lg" style={{ color: 'var(--muted-foreground)' }}>
                Stop financial leaking. Track every rupee automatically.
              </p>
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="rounded-lg p-8 space-y-6"
              style={{ background: 'var(--card)' }}
            >
              <div>
                <label className="block mb-2" style={{ color: 'var(--foreground)' }}>
                  What's your monthly allowance?
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl" style={{ color: 'var(--muted-foreground)' }}>₹</span>
                  <Input
                    type="number"
                    value={monthlyIncome}
                    onChange={(e) => setMonthlyIncome(e.target.value)}
                    placeholder="5000"
                    className="pl-12 text-2xl h-16"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="text-center p-4 rounded-lg" style={{ background: 'var(--muted)' }}>
                  <TrendingUp className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--secondary)' }} />
                  <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>AI Categorization</div>
                </div>
                <div className="text-center p-4 rounded-lg" style={{ background: 'var(--muted)' }}>
                  <Calculator className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--secondary)' }} />
                  <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Smart Budgets</div>
                </div>
                <div className="text-center p-4 rounded-lg" style={{ background: 'var(--muted)' }}>
                  <Wallet className="w-8 h-8 mx-auto mb-2" style={{ color: 'var(--secondary)' }} />
                  <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Auto Tracking</div>
                </div>
              </div>

              <Button
                onClick={handleNext}
                disabled={!monthlyIncome}
                className="w-full h-12 text-lg"
                style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
              >
                Continue <ArrowRight className="ml-2" />
              </Button>
            </motion.div>
          </div>
        )}

        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-bold" style={{ color: 'var(--foreground)' }}>
                Set Your Budget Categories
              </h2>
              <p style={{ color: 'var(--muted-foreground)' }}>
                AI will auto-adjust these based on your spending patterns
              </p>
            </div>

            <div className="rounded-lg p-6 space-y-4" style={{ background: 'var(--card)' }}>
              {budgets.map((budget, index) => (
                <div key={budget.name} className="flex items-center gap-4">
                  <span className="text-3xl">{budget.icon}</span>
                  <div className="flex-1">
                    <div className="text-sm mb-1" style={{ color: 'var(--muted-foreground)' }}>{budget.name}</div>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted-foreground)' }}>₹</span>
                      <Input
                        type="number"
                        value={budget.amount || ''}
                        onChange={(e) => handleBudgetChange(index, e.target.value)}
                        placeholder="0"
                        className="pl-8"
                      />
                    </div>
                  </div>
                </div>
              ))}

              <div className="pt-4 border-t" style={{ borderColor: 'var(--border)' }}>
                <div className="flex justify-between mb-2">
                  <span style={{ color: 'var(--muted-foreground)' }}>Total Budget</span>
                  <span className="font-bold" style={{ color: 'var(--foreground)' }}>₹{totalBudget}</span>
                </div>
                <div className="flex justify-between mb-4">
                  <span style={{ color: 'var(--muted-foreground)' }}>Remaining</span>
                  <span
                    className="font-bold"
                    style={{ color: remaining >= 0 ? 'var(--secondary)' : 'var(--destructive)' }}
                  >
                    ₹{remaining.toFixed(0)}
                  </span>
                </div>
                <Button
                  onClick={handleNext}
                  className="w-full h-12 text-lg"
                  style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
                >
                  Start Tracking <ArrowRight className="ml-2" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
