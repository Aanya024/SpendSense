import { motion } from 'motion/react';
import { TrendingDown, TrendingUp, Wallet, AlertCircle, Sparkles } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface Transaction {
  id: string;
  vendor: string;
  amount: number;
  category: string;
  date: Date;
  aiParsed: boolean;
}

interface BudgetCategory {
  name: string;
  amount: number;
  icon: string;
  spent?: number;
}

interface DashboardProps {
  budgets: BudgetCategory[];
  transactions: Transaction[];
  totalIncome: number;
}

export default function Dashboard({ budgets, transactions, totalIncome }: DashboardProps) {
  const totalSpent = transactions.reduce((sum, t) => sum + t.amount, 0);
  const totalBudget = budgets.reduce((sum, b) => sum + b.amount, 0);
  const remaining = totalIncome - totalSpent;
  const leakPercentage = ((totalSpent / totalIncome) * 100).toFixed(1);

  const spendingByCategory = budgets.map(budget => {
    const spent = transactions
      .filter(t => t.category === budget.name)
      .reduce((sum, t) => sum + t.amount, 0);
    return {
      ...budget,
      spent,
      percentage: budget.amount > 0 ? (spent / budget.amount) * 100 : 0
    };
  });

  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const dayTransactions = transactions.filter(t => {
      const tDate = new Date(t.date);
      return tDate.toDateString() === date.toDateString();
    });
    const total = dayTransactions.reduce((sum, t) => sum + t.amount, 0);
    return {
      day: date.toLocaleDateString('en-US', { weekday: 'short' }),
      amount: total
    };
  });

  const aiInsight = totalSpent > totalBudget * 0.8
    ? `You're spending ${leakPercentage}% of your allowance. AI suggests reducing ${spendingByCategory.sort((a, b) => b.percentage - a.percentage)[0].name} expenses.`
    : `Great control! You've spent ${leakPercentage}% of your allowance. Keep it up!`;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        <div className="rounded-lg p-6" style={{ background: 'var(--card)' }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Total Spent</span>
            <TrendingDown className="w-4 h-4" style={{ color: 'var(--destructive)' }} />
          </div>
          <div className="text-3xl font-bold" style={{ color: 'var(--foreground)' }}>₹{totalSpent.toFixed(0)}</div>
          <div className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>
            {leakPercentage}% of allowance
          </div>
        </div>

        <div className="rounded-lg p-6" style={{ background: 'var(--card)' }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Remaining</span>
            <Wallet className="w-4 h-4" style={{ color: 'var(--secondary)' }} />
          </div>
          <div className="text-3xl font-bold" style={{ color: remaining > 0 ? 'var(--secondary)' : 'var(--destructive)' }}>
            ₹{remaining.toFixed(0)}
          </div>
          <div className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>
            {((remaining / totalIncome) * 100).toFixed(1)}% left
          </div>
        </div>

        <div className="rounded-lg p-6" style={{ background: 'var(--card)' }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>AI Tracked</span>
            <Sparkles className="w-4 h-4" style={{ color: 'var(--primary)' }} />
          </div>
          <div className="text-3xl font-bold" style={{ color: 'var(--foreground)' }}>
            {transactions.filter(t => t.aiParsed).length}
          </div>
          <div className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>
            of {transactions.length} transactions
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="rounded-lg p-6"
        style={{ background: 'var(--card)' }}
      >
        <div className="flex items-start gap-3 mb-4">
          <AlertCircle className="w-5 h-5 mt-0.5" style={{ color: totalSpent > totalBudget * 0.8 ? 'var(--destructive)' : 'var(--secondary)' }} />
          <div>
            <div className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>AI Insight</div>
            <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{aiInsight}</div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="rounded-lg p-6"
        style={{ background: 'var(--card)' }}
      >
        <h3 className="font-medium mb-4" style={{ color: 'var(--foreground)' }}>7-Day Spending Trend</h3>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={last7Days}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="day" stroke="var(--muted-foreground)" />
            <YAxis stroke="var(--muted-foreground)" />
            <Tooltip
              contentStyle={{
                background: 'var(--card)',
                border: '1px solid var(--border)',
                borderRadius: '8px',
                color: 'var(--foreground)'
              }}
            />
            <Line
              type="monotone"
              dataKey="amount"
              stroke="var(--primary)"
              strokeWidth={2}
              dot={{ fill: 'var(--primary)', r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="rounded-lg p-6"
        style={{ background: 'var(--card)' }}
      >
        <h3 className="font-medium mb-4" style={{ color: 'var(--foreground)' }}>Budget vs Spent</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={spendingByCategory}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="name" stroke="var(--muted-foreground)" />
            <YAxis stroke="var(--muted-foreground)" />
            <Tooltip
              contentStyle={{
                background: 'var(--card)',
                border: '1px solid var(--border)',
                borderRadius: '8px',
                color: 'var(--foreground)'
              }}
            />
            <Bar dataKey="amount" name="Budget" fill="var(--muted)" radius={[8, 8, 0, 0]} />
            <Bar dataKey="spent" name="Spent" radius={[8, 8, 0, 0]}>
              {spendingByCategory.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={entry.percentage > 100 ? 'var(--destructive)' : entry.percentage > 80 ? 'var(--chart-3)' : 'var(--secondary)'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="space-y-3"
      >
        <h3 className="font-medium" style={{ color: 'var(--foreground)' }}>Category Breakdown</h3>
        {spendingByCategory.map((category, index) => (
          <div
            key={category.name}
            className="rounded-lg p-4"
            style={{ background: 'var(--card)' }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{category.icon}</span>
                <span className="font-medium" style={{ color: 'var(--foreground)' }}>{category.name}</span>
              </div>
              <div className="text-right">
                <div className="font-bold" style={{ color: 'var(--foreground)' }}>
                  ₹{category.spent.toFixed(0)} / ₹{category.amount}
                </div>
                <div className="text-sm" style={{ color: category.percentage > 100 ? 'var(--destructive)' : 'var(--muted-foreground)' }}>
                  {category.percentage.toFixed(0)}%
                </div>
              </div>
            </div>
            <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--muted)' }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(category.percentage, 100)}%` }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.5 }}
                className="h-full rounded-full"
                style={{
                  background: category.percentage > 100 ? 'var(--destructive)' : category.percentage > 80 ? 'var(--chart-3)' : 'var(--secondary)'
                }}
              />
            </div>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
