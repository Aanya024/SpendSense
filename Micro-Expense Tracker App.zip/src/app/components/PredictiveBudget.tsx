import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, Sparkles, AlertCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface BudgetCategory {
  name: string;
  amount: number;
  icon: string;
  spent?: number;
}

interface Transaction {
  id: string;
  amount: number;
  category: string;
  date: Date;
}

interface PredictiveBudgetProps {
  budgets: BudgetCategory[];
  transactions: Transaction[];
  totalIncome: number;
}

export default function PredictiveBudget({ budgets, transactions, totalIncome }: PredictiveBudgetProps) {
  const today = new Date();
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
  const daysPassed = today.getDate();
  const daysRemaining = daysInMonth - daysPassed;

  const totalSpent = transactions.reduce((sum, t) => sum + t.amount, 0);
  const dailyAverage = totalSpent / daysPassed;
  const projectedTotal = dailyAverage * daysInMonth;
  const projectedRemaining = projectedTotal - totalSpent;

  const forecastData = Array.from({ length: daysInMonth }, (_, i) => {
    const day = i + 1;
    let actual = 0;

    if (day <= daysPassed) {
      actual = transactions
        .filter(t => new Date(t.date).getDate() <= day)
        .reduce((sum, t) => sum + t.amount, 0);
    }

    const predicted = day > daysPassed ? dailyAverage * day : null;

    return {
      day,
      actual: day <= daysPassed ? actual : null,
      predicted: predicted,
      budget: (totalIncome / daysInMonth) * day
    };
  });

  const categoryPredictions = budgets.map(budget => {
    const spent = transactions
      .filter(t => t.category === budget.name)
      .reduce((sum, t) => sum + t.amount, 0);

    const categoryDailyAvg = spent / daysPassed;
    const projected = categoryDailyAvg * daysInMonth;
    const overBudget = projected > budget.amount;

    return {
      ...budget,
      spent,
      projected,
      overBudget,
      adjustment: overBudget ? Math.ceil(projected - budget.amount) : 0
    };
  });

  const suggestedAdjustments = categoryPredictions.filter(c => c.overBudget);
  const hasAdjustments = suggestedAdjustments.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold" style={{ color: 'var(--foreground)' }}>AI Forecast</h2>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>
          <Sparkles className="w-4 h-4" />
          <span className="text-sm font-medium">Predictive</span>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-1 md:grid-cols-2 gap-4"
      >
        <div className="rounded-lg p-6" style={{ background: 'var(--card)' }}>
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5" style={{ color: 'var(--primary)' }} />
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Projected End-of-Month</span>
          </div>
          <div className="text-3xl font-bold mb-1" style={{ color: projectedTotal > totalIncome ? 'var(--destructive)' : 'var(--foreground)' }}>
            ₹{projectedTotal.toFixed(0)}
          </div>
          <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            {projectedTotal > totalIncome ? 'Over budget by' : 'Under budget by'} ₹{Math.abs(totalIncome - projectedTotal).toFixed(0)}
          </div>
        </div>

        <div className="rounded-lg p-6" style={{ background: 'var(--card)' }}>
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="w-5 h-5" style={{ color: 'var(--secondary)' }} />
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Safe Daily Spending</span>
          </div>
          <div className="text-3xl font-bold mb-1" style={{ color: 'var(--foreground)' }}>
            ₹{((totalIncome - totalSpent) / daysRemaining).toFixed(0)}
          </div>
          <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            For next {daysRemaining} days
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="rounded-lg p-6"
        style={{ background: 'var(--card)' }}
      >
        <h3 className="font-medium mb-4" style={{ color: 'var(--foreground)' }}>Spending Forecast</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={forecastData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis
              dataKey="day"
              stroke="var(--muted-foreground)"
              label={{ value: 'Day of Month', position: 'insideBottom', offset: -5, fill: 'var(--muted-foreground)' }}
            />
            <YAxis stroke="var(--muted-foreground)" />
            <Tooltip
              contentStyle={{
                background: 'var(--card)',
                border: '1px solid var(--border)',
                borderRadius: '8px',
                color: 'var(--foreground)'
              }}
            />
            <ReferenceLine
              y={totalIncome}
              stroke="var(--destructive)"
              strokeDasharray="3 3"
              label={{ value: 'Budget Limit', position: 'right', fill: 'var(--destructive)' }}
            />
            <Line
              type="monotone"
              dataKey="actual"
              stroke="var(--primary)"
              strokeWidth={3}
              dot={false}
              name="Actual"
            />
            <Line
              type="monotone"
              dataKey="predicted"
              stroke="var(--chart-3)"
              strokeWidth={2}
              strokeDasharray="5 5"
              dot={false}
              name="Predicted"
            />
            <Line
              type="monotone"
              dataKey="budget"
              stroke="var(--secondary)"
              strokeWidth={1}
              strokeDasharray="3 3"
              dot={false}
              name="Ideal"
            />
          </LineChart>
        </ResponsiveContainer>
      </motion.div>

      {hasAdjustments && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="rounded-lg p-6"
          style={{ background: 'var(--card)', border: '1px solid var(--destructive)' }}
        >
          <div className="flex items-start gap-3 mb-4">
            <AlertCircle className="w-5 h-5 mt-0.5" style={{ color: 'var(--destructive)' }} />
            <div>
              <div className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>
                Next Month's Suggested Adjustments
              </div>
              <div className="text-sm mb-3" style={{ color: 'var(--muted-foreground)' }}>
                Based on current spending patterns, AI recommends these budget changes
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {suggestedAdjustments.map((category, index) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className="rounded-lg p-4"
                style={{ background: 'var(--muted)' }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{category.icon}</span>
                    <span className="font-medium" style={{ color: 'var(--foreground)' }}>{category.name}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                      Current: ₹{category.amount}
                    </div>
                    <div className="font-bold" style={{ color: 'var(--destructive)' }}>
                      Suggested: ₹{category.projected.toFixed(0)} (+₹{category.adjustment})
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-4 p-3 rounded" style={{ background: 'var(--background)' }}>
            <div className="text-sm" style={{ color: 'var(--foreground)' }}>
              💡 <strong>Smart tip:</strong> These adjustments will be auto-applied next month by reallocating from categories you use less
            </div>
          </div>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="space-y-3"
      >
        <h3 className="font-medium" style={{ color: 'var(--foreground)' }}>Category Forecasts</h3>
        {categoryPredictions.map((category, index) => (
          <div
            key={category.name}
            className="rounded-lg p-4"
            style={{ background: 'var(--card)' }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{category.icon}</span>
                <span className="font-medium" style={{ color: 'var(--foreground)' }}>{category.name}</span>
              </div>
              <div className="text-right">
                <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                  Current: ₹{category.spent.toFixed(0)}
                </div>
                <div
                  className="font-bold"
                  style={{ color: category.overBudget ? 'var(--destructive)' : 'var(--secondary)' }}
                >
                  Projected: ₹{category.projected.toFixed(0)}
                </div>
              </div>
            </div>
            <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--muted)' }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min((category.projected / category.amount) * 100, 100)}%` }}
                transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                className="h-full rounded-full"
                style={{
                  background: category.overBudget ? 'var(--destructive)' : 'var(--secondary)'
                }}
              />
            </div>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
