import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface Transaction {
  id: string;
  vendor: string;
  amount: number;
  category: string;
  date: Date;
}

interface BudgetCategory {
  name: string;
  amount: number;
  spent?: number;
}

interface ChatbotProps {
  transactions: Transaction[];
  budgets: BudgetCategory[];
  totalIncome: number;
}

export default function Chatbot({ transactions, budgets, totalIncome }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! I'm your AI finance assistant. I can help you understand your spending patterns, give budget advice, or answer questions about your transactions. What would you like to know?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage: string): string => {
    const msg = userMessage.toLowerCase();
    const totalSpent = transactions.reduce((sum, t) => sum + t.amount, 0);
    const remaining = totalIncome - totalSpent;

    if (msg.includes('spent') || msg.includes('spending')) {
      return `You've spent ₹${totalSpent.toFixed(0)} so far this month, which is ${((totalSpent / totalIncome) * 100).toFixed(1)}% of your allowance. You have ₹${remaining.toFixed(0)} remaining.`;
    }

    if (msg.includes('food') || msg.includes('eat')) {
      const foodBudget = budgets.find(b => b.name === 'Food');
      const foodSpent = transactions
        .filter(t => t.category === 'Food')
        .reduce((sum, t) => sum + t.amount, 0);
      return `Your food budget is ₹${foodBudget?.amount || 0}, and you've spent ₹${foodSpent.toFixed(0)} so far. ${foodSpent > (foodBudget?.amount || 0) * 0.8 ? "You're nearing your limit! Consider cooking at home to save money." : "You're doing well with your food expenses!"}`;
    }

    if (msg.includes('save') || msg.includes('saving')) {
      return `Based on your current spending rate, you could save ₹${remaining.toFixed(0)} this month. To save more, I suggest reducing spending in categories where you've exceeded 80% of your budget.`;
    }

    if (msg.includes('suggest') || msg.includes('advice') || msg.includes('tip')) {
      const overBudget = budgets.filter(b => {
        const spent = transactions.filter(t => t.category === b.name).reduce((sum, t) => sum + t.amount, 0);
        return spent > b.amount * 0.8;
      });
      if (overBudget.length > 0) {
        return `You're spending heavily on ${overBudget[0].name}. Try setting daily limits or finding cheaper alternatives to stay within budget.`;
      }
      return "You're managing your budget well! Keep tracking your expenses and you'll avoid financial leaking.";
    }

    if (msg.includes('transaction') || msg.includes('recent')) {
      const recent = transactions.slice(-3);
      if (recent.length === 0) return "You don't have any transactions yet.";
      const list = recent.map(t => `₹${t.amount} at ${t.vendor} (${t.category})`).join(', ');
      return `Your recent transactions: ${list}`;
    }

    if (msg.includes('budget')) {
      const total = budgets.reduce((sum, b) => sum + b.amount, 0);
      return `Your total monthly budget is ₹${total}. The biggest allocation is for ${budgets.sort((a, b) => b.amount - a.amount)[0].name} at ₹${budgets[0].amount}.`;
    }

    if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey')) {
      return "Hello! How can I help you manage your finances today?";
    }

    return "I can help you with spending analysis, budget advice, transaction history, and savings tips. What would you like to know?";
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateBotResponse(input),
        sender: 'bot',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-3 mb-4 pb-4 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--primary)' }}>
          <Bot className="w-6 h-6" style={{ color: 'var(--primary-foreground)' }} />
        </div>
        <div>
          <h2 className="text-xl font-bold" style={{ color: 'var(--foreground)' }}>AI Assistant</h2>
          <div className="flex items-center gap-1.5 text-sm" style={{ color: 'var(--muted-foreground)' }}>
            <Sparkles className="w-3 h-3" />
            <span>Always here to help</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex gap-3 ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                style={{
                  background: message.sender === 'bot' ? 'var(--primary)' : 'var(--secondary)'
                }}
              >
                {message.sender === 'bot' ? (
                  <Bot className="w-4 h-4" style={{ color: 'var(--primary-foreground)' }} />
                ) : (
                  <User className="w-4 h-4" style={{ color: 'var(--secondary-foreground)' }} />
                )}
              </div>
              <div
                className={`rounded-2xl px-4 py-3 max-w-[80%] ${
                  message.sender === 'user' ? 'rounded-tr-sm' : 'rounded-tl-sm'
                }`}
                style={{
                  background: message.sender === 'bot' ? 'var(--card)' : 'var(--primary)',
                  color: message.sender === 'bot' ? 'var(--foreground)' : 'var(--primary-foreground)'
                }}
              >
                <div className="text-sm leading-relaxed">{message.text}</div>
                <div
                  className="text-xs mt-1 opacity-60"
                >
                  {message.timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex gap-3"
          >
            <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'var(--primary)' }}>
              <Bot className="w-4 h-4" style={{ color: 'var(--primary-foreground)' }} />
            </div>
            <div className="rounded-2xl rounded-tl-sm px-4 py-3" style={{ background: 'var(--card)' }}>
              <div className="flex gap-1">
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ repeat: Infinity, duration: 1.5, delay: 0 }}
                  className="w-2 h-2 rounded-full"
                  style={{ background: 'var(--primary)' }}
                />
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }}
                  className="w-2 h-2 rounded-full"
                  style={{ background: 'var(--primary)' }}
                />
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }}
                  className="w-2 h-2 rounded-full"
                  style={{ background: 'var(--primary)' }}
                />
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask about your spending..."
          className="flex-1"
        />
        <Button
          onClick={handleSend}
          disabled={!input.trim()}
          style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
