import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Users, Plus, X, Check, ArrowRight, DollarSign, UserPlus, TrendingDown } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { toast } from 'sonner';

interface Friend {
  id: string;
  name: string;
  avatar: string;
}

interface SplitExpense {
  id: string;
  description: string;
  totalAmount: number;
  paidBy: string;
  date: Date;
  participants: {
    id: string;
    name: string;
    amount: number;
    settled: boolean;
  }[];
  category: string;
}

interface Settlement {
  from: string;
  to: string;
  amount: number;
}

interface BillSplitterProps {
  friends: Friend[];
  splitExpenses: SplitExpense[];
  onAddFriend: (name: string) => void;
  onAddExpense: (expense: Omit<SplitExpense, 'id' | 'date'>) => void;
  onSettleUp: (expenseId: string, participantId: string) => void;
}

export default function BillSplitter({
  friends,
  splitExpenses,
  onAddFriend,
  onAddExpense,
  onSettleUp
}: BillSplitterProps) {
  const [addExpenseOpen, setAddExpenseOpen] = useState(false);
  const [addFriendOpen, setAddFriendOpen] = useState(false);
  const [newFriendName, setNewFriendName] = useState('');

  // Add expense form state
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [paidBy, setPaidBy] = useState('You');
  const [selectedFriends, setSelectedFriends] = useState<string[]>(['You']);
  const [splitType, setSplitType] = useState<'equal' | 'custom'>('equal');
  const [customSplits, setCustomSplits] = useState<{ [key: string]: number }>({});

  const calculateBalances = (): { [key: string]: number } => {
    const balances: { [key: string]: number } = { You: 0 };
    friends.forEach(f => balances[f.name] = 0);

    splitExpenses.forEach(expense => {
      expense.participants.forEach(participant => {
        if (!participant.settled) {
          if (participant.name === expense.paidBy) {
            balances[participant.name] = (balances[participant.name] || 0) + (expense.totalAmount - participant.amount);
          } else {
            balances[participant.name] = (balances[participant.name] || 0) - participant.amount;
          }
        }
      });
    });

    return balances;
  };

  const getSettlements = (): Settlement[] => {
    const balances = calculateBalances();
    const settlements: Settlement[] = [];

    const creditors = Object.entries(balances).filter(([_, amt]) => amt > 0.01).sort((a, b) => b[1] - a[1]);
    const debtors = Object.entries(balances).filter(([_, amt]) => amt < -0.01).sort((a, b) => a[1] - b[1]);

    let i = 0, j = 0;
    while (i < creditors.length && j < debtors.length) {
      const [creditor, creditAmt] = creditors[i];
      const [debtor, debtAmt] = debtors[j];

      const settleAmount = Math.min(creditAmt, Math.abs(debtAmt));
      settlements.push({
        from: debtor,
        to: creditor,
        amount: settleAmount
      });

      creditors[i] = [creditor, creditAmt - settleAmount];
      debtors[j] = [debtor, debtAmt + settleAmount];

      if (creditors[i][1] < 0.01) i++;
      if (Math.abs(debtors[j][1]) < 0.01) j++;
    }

    return settlements;
  };

  const handleAddExpense = () => {
    if (!description || !amount || selectedFriends.length === 0) {
      toast.error('Please fill all fields and select participants');
      return;
    }

    const totalAmount = parseFloat(amount);
    let participants;

    if (splitType === 'equal') {
      const perPerson = totalAmount / selectedFriends.length;
      participants = selectedFriends.map(name => ({
        id: name === 'You' ? 'you' : friends.find(f => f.name === name)?.id || '',
        name,
        amount: perPerson,
        settled: false
      }));
    } else {
      participants = selectedFriends.map(name => ({
        id: name === 'You' ? 'you' : friends.find(f => f.name === name)?.id || '',
        name,
        amount: customSplits[name] || 0,
        settled: false
      }));
    }

    onAddExpense({
      description,
      totalAmount,
      paidBy,
      participants,
      category: 'Split'
    });

    setDescription('');
    setAmount('');
    setPaidBy('You');
    setSelectedFriends(['You']);
    setCustomSplits({});
    setAddExpenseOpen(false);
    toast.success('Expense split successfully!');
  };

  const handleAddFriend = () => {
    if (newFriendName.trim()) {
      onAddFriend(newFriendName.trim());
      setNewFriendName('');
      setAddFriendOpen(false);
      toast.success(`${newFriendName} added to your group!`);
    }
  };

  const toggleFriend = (name: string) => {
    if (selectedFriends.includes(name)) {
      if (selectedFriends.length > 1) {
        setSelectedFriends(selectedFriends.filter(f => f !== name));
      }
    } else {
      setSelectedFriends([...selectedFriends, name]);
    }
  };

  const balances = calculateBalances();
  const settlements = getSettlements();
  const totalOwed = Object.values(balances).reduce((sum, val) => sum + (val > 0 ? val : 0), 0);
  const totalOwe = Math.abs(Object.values(balances).reduce((sum, val) => sum + (val < 0 ? val : 0), 0));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold" style={{ color: 'var(--foreground)' }}>Bill Splitter</h2>
          <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            Split expenses with friends automatically
          </p>
        </div>

        <Dialog open={addFriendOpen} onOpenChange={setAddFriendOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <UserPlus className="w-4 h-4 mr-2" />
              Add Friend
            </Button>
          </DialogTrigger>
          <DialogContent style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <DialogHeader>
              <DialogTitle style={{ color: 'var(--foreground)' }}>Add Friend</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <Input
                value={newFriendName}
                onChange={(e) => setNewFriendName(e.target.value)}
                placeholder="Friend's name"
                onKeyPress={(e) => e.key === 'Enter' && handleAddFriend()}
              />
              <Button onClick={handleAddFriend} className="w-full" style={{ background: 'var(--primary)' }}>
                Add Friend
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-lg p-6"
          style={{ background: 'var(--card)' }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>You're Owed</span>
            <TrendingDown className="w-4 h-4" style={{ color: 'var(--secondary)' }} />
          </div>
          <div className="text-3xl font-bold" style={{ color: 'var(--secondary)' }}>
            ₹{totalOwed.toFixed(0)}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-lg p-6"
          style={{ background: 'var(--card)' }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>You Owe</span>
            <TrendingDown className="w-4 h-4" style={{ color: 'var(--destructive)' }} />
          </div>
          <div className="text-3xl font-bold" style={{ color: 'var(--destructive)' }}>
            ₹{totalOwe.toFixed(0)}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-lg p-6"
          style={{ background: 'var(--card)' }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Total Splits</span>
            <Users className="w-4 h-4" style={{ color: 'var(--primary)' }} />
          </div>
          <div className="text-3xl font-bold" style={{ color: 'var(--foreground)' }}>
            {splitExpenses.length}
          </div>
        </motion.div>
      </div>

      {settlements.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-lg p-6"
          style={{ background: 'var(--card)' }}
        >
          <h3 className="font-medium mb-4" style={{ color: 'var(--foreground)' }}>Suggested Settlements</h3>
          <div className="space-y-3">
            {settlements.map((settlement, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-lg"
                style={{ background: 'var(--muted)' }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'var(--primary)' }}>
                    {settlement.from.charAt(0)}
                  </div>
                  <span style={{ color: 'var(--foreground)' }}>{settlement.from}</span>
                  <ArrowRight className="w-4 h-4" style={{ color: 'var(--muted-foreground)' }} />
                  <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'var(--secondary)' }}>
                    {settlement.to.charAt(0)}
                  </div>
                  <span style={{ color: 'var(--foreground)' }}>{settlement.to}</span>
                </div>
                <span className="font-bold" style={{ color: 'var(--secondary)' }}>₹{settlement.amount.toFixed(0)}</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      <div className="flex items-center justify-between">
        <h3 className="font-medium" style={{ color: 'var(--foreground)' }}>Recent Splits</h3>

        <Dialog open={addExpenseOpen} onOpenChange={setAddExpenseOpen}>
          <DialogTrigger asChild>
            <Button style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>
              <Plus className="w-4 h-4 mr-2" />
              Split Bill
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <DialogHeader>
              <DialogTitle style={{ color: 'var(--foreground)' }}>Split a Bill</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <label className="text-sm mb-2 block" style={{ color: 'var(--muted-foreground)' }}>Description</label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g., Dinner at Pizza Hut"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm mb-2 block" style={{ color: 'var(--muted-foreground)' }}>Total Amount</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted-foreground)' }}>₹</span>
                    <Input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="500"
                      className="pl-8"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm mb-2 block" style={{ color: 'var(--muted-foreground)' }}>Paid By</label>
                  <select
                    value={paidBy}
                    onChange={(e) => setPaidBy(e.target.value)}
                    className="w-full h-10 px-3 rounded-md"
                    style={{ background: 'var(--input-background)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
                  >
                    <option value="You">You</option>
                    {friends.map(f => (
                      <option key={f.id} value={f.name}>{f.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-sm mb-2 block" style={{ color: 'var(--muted-foreground)' }}>Split With</label>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => toggleFriend('You')}
                    className="px-4 py-2 rounded-full flex items-center gap-2"
                    style={{
                      background: selectedFriends.includes('You') ? 'var(--primary)' : 'var(--muted)',
                      color: selectedFriends.includes('You') ? 'var(--primary-foreground)' : 'var(--foreground)'
                    }}
                  >
                    You
                    {selectedFriends.includes('You') && <Check className="w-4 h-4" />}
                  </button>
                  {friends.map(friend => (
                    <button
                      key={friend.id}
                      onClick={() => toggleFriend(friend.name)}
                      className="px-4 py-2 rounded-full flex items-center gap-2"
                      style={{
                        background: selectedFriends.includes(friend.name) ? 'var(--primary)' : 'var(--muted)',
                        color: selectedFriends.includes(friend.name) ? 'var(--primary-foreground)' : 'var(--foreground)'
                      }}
                    >
                      {friend.name}
                      {selectedFriends.includes(friend.name) && <Check className="w-4 h-4" />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm mb-2 block" style={{ color: 'var(--muted-foreground)' }}>Split Type</label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSplitType('equal')}
                    className="flex-1 py-2 rounded-md"
                    style={{
                      background: splitType === 'equal' ? 'var(--primary)' : 'var(--muted)',
                      color: splitType === 'equal' ? 'var(--primary-foreground)' : 'var(--foreground)'
                    }}
                  >
                    Equal Split
                  </button>
                  <button
                    onClick={() => setSplitType('custom')}
                    className="flex-1 py-2 rounded-md"
                    style={{
                      background: splitType === 'custom' ? 'var(--primary)' : 'var(--muted)',
                      color: splitType === 'custom' ? 'var(--primary-foreground)' : 'var(--foreground)'
                    }}
                  >
                    Custom Split
                  </button>
                </div>
              </div>

              {splitType === 'equal' && amount && (
                <div className="p-4 rounded-lg" style={{ background: 'var(--muted)' }}>
                  <div className="text-sm mb-1" style={{ color: 'var(--muted-foreground)' }}>Each person pays:</div>
                  <div className="text-2xl font-bold" style={{ color: 'var(--secondary)' }}>
                    ₹{(parseFloat(amount) / selectedFriends.length).toFixed(2)}
                  </div>
                </div>
              )}

              <Button
                onClick={handleAddExpense}
                className="w-full"
                style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
              >
                Split Bill
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        <AnimatePresence>
          {splitExpenses.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12 rounded-lg"
              style={{ background: 'var(--card)' }}
            >
              <Users className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--muted-foreground)' }} />
              <div className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>No split bills yet</div>
              <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                Add friends and start splitting expenses
              </div>
            </motion.div>
          ) : (
            splitExpenses.map((expense, index) => (
              <motion.div
                key={expense.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="rounded-lg p-4"
                style={{ background: 'var(--card)' }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>
                      {expense.description}
                    </div>
                    <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                      Paid by {expense.paidBy} • {expense.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold" style={{ color: 'var(--foreground)' }}>
                      ₹{expense.totalAmount.toFixed(0)}
                    </div>
                    <div className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                      {expense.participants.length} people
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  {expense.participants.map(participant => (
                    <div
                      key={participant.id}
                      className="flex items-center justify-between p-2 rounded"
                      style={{ background: 'var(--muted)' }}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs" style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>
                          {participant.name.charAt(0)}
                        </div>
                        <span className="text-sm" style={{ color: 'var(--foreground)' }}>{participant.name}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                          ₹{participant.amount.toFixed(2)}
                        </span>
                        {participant.settled ? (
                          <span className="text-xs px-2 py-1 rounded" style={{ background: 'var(--secondary)', color: 'var(--secondary-foreground)' }}>
                            Settled
                          </span>
                        ) : participant.name !== expense.paidBy && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              onSettleUp(expense.id, participant.id);
                              toast.success(`${participant.name} settled ₹${participant.amount.toFixed(0)}`);
                            }}
                          >
                            Settle
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
