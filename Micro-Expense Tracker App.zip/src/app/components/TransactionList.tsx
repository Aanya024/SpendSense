import { motion } from 'motion/react';
import { Sparkles, Calendar, Tag } from 'lucide-react';

interface Transaction {
  id: string;
  vendor: string;
  amount: number;
  category: string;
  date: Date;
  aiParsed: boolean;
  rawText?: string;
}

interface TransactionListProps {
  transactions: Transaction[];
}

const categoryIcons: Record<string, string> = {
  'Food': '🍔',
  'Transport': '🚌',
  'Entertainment': '🎬',
  'Shopping': '🛍️',
  'Other': '📦'
};

export default function TransactionList({ transactions }: TransactionListProps) {
  const sortedTransactions = [...transactions].sort((a, b) =>
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const groupedByDate = sortedTransactions.reduce((groups, transaction) => {
    const date = new Date(transaction.date).toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(transaction);
    return groups;
  }, {} as Record<string, Transaction[]>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold" style={{ color: 'var(--foreground)' }}>Transactions</h2>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full" style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>
          <Sparkles className="w-4 h-4" />
          <span className="text-sm font-medium">AI Powered</span>
        </div>
      </div>

      {Object.entries(groupedByDate).map(([date, dayTransactions], groupIndex) => (
        <motion.div
          key={date}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: groupIndex * 0.1 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4" style={{ color: 'var(--muted-foreground)' }} />
            <span className="text-sm font-medium" style={{ color: 'var(--muted-foreground)' }}>{date}</span>
          </div>

          <div className="space-y-2">
            {dayTransactions.map((transaction, index) => (
              <motion.div
                key={transaction.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: groupIndex * 0.1 + index * 0.05 }}
                className="rounded-lg p-4 hover:scale-[1.02] transition-transform cursor-pointer"
                style={{ background: 'var(--card)' }}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="text-2xl mt-0.5">
                      {categoryIcons[transaction.category] || '📦'}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium" style={{ color: 'var(--foreground)' }}>
                          {transaction.vendor}
                        </span>
                        {transaction.aiParsed && (
                          <Sparkles className="w-3 h-3" style={{ color: 'var(--primary)' }} />
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <Tag className="w-3 h-3" style={{ color: 'var(--muted-foreground)' }} />
                        <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                          {transaction.category}
                        </span>
                      </div>
                      {transaction.rawText && (
                        <div className="text-xs mt-2 p-2 rounded" style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}>
                          <div className="opacity-75">AI parsed from:</div>
                          <div className="mt-0.5 font-mono">{transaction.rawText}</div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold" style={{ color: 'var(--destructive)' }}>
                      -₹{transaction.amount.toFixed(0)}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
                      {new Date(transaction.date).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      ))}

      {transactions.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12 rounded-lg"
          style={{ background: 'var(--card)' }}
        >
          <Sparkles className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--muted-foreground)' }} />
          <div className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>No transactions yet</div>
          <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            AI will automatically track your expenses from SMS notifications
          </div>
        </motion.div>
      )}
    </div>
  );
}
