import { motion } from 'motion/react';
import { Clock, Pause, Play, Trash2, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';

interface Subscription {
  id: string;
  name: string;
  amount: number;
  renewalDate: Date;
  status: 'active' | 'paused';
  icon: string;
}

interface SubscriptionTrackerProps {
  subscriptions: Subscription[];
  onPause: (id: string) => void;
  onResume: (id: string) => void;
  onCancel: (id: string) => void;
}

export default function SubscriptionTracker({
  subscriptions,
  onPause,
  onResume,
  onCancel
}: SubscriptionTrackerProps) {
  const getDaysUntilRenewal = (date: Date) => {
    const now = new Date();
    const renewal = new Date(date);
    const diffTime = renewal.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const activeSubscriptions = subscriptions.filter(s => s.status === 'active');
  const pausedSubscriptions = subscriptions.filter(s => s.status === 'paused');
  const totalMonthly = activeSubscriptions.reduce((sum, s) => sum + s.amount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2" style={{ color: 'var(--foreground)' }}>Subscriptions</h2>
        <div className="flex items-center gap-4">
          <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            {activeSubscriptions.length} active
          </div>
          <div className="text-sm font-medium" style={{ color: 'var(--secondary)' }}>
            ₹{totalMonthly}/month
          </div>
        </div>
      </div>

      {activeSubscriptions.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-3"
        >
          <h3 className="font-medium" style={{ color: 'var(--foreground)' }}>Active</h3>
          {activeSubscriptions.map((sub, index) => {
            const daysLeft = getDaysUntilRenewal(sub.renewalDate);
            const isExpiringSoon = daysLeft <= 7;

            return (
              <motion.div
                key={sub.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="rounded-lg p-4"
                style={{
                  background: 'var(--card)',
                  border: isExpiringSoon ? '1px solid var(--destructive)' : 'none'
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <div className="text-3xl">{sub.icon}</div>
                    <div>
                      <div className="font-medium mb-0.5" style={{ color: 'var(--foreground)' }}>
                        {sub.name}
                      </div>
                      <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                        ₹{sub.amount}/month
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5" style={{ color: isExpiringSoon ? 'var(--destructive)' : 'var(--muted-foreground)' }}>
                      <Clock className="w-4 h-4" />
                      <span className="text-sm font-medium">
                        {daysLeft} {daysLeft === 1 ? 'day' : 'days'}
                      </span>
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
                      Renews {new Date(sub.renewalDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </div>
                  </div>
                </div>

                {isExpiringSoon && (
                  <div className="flex items-center gap-2 mb-3 p-2 rounded" style={{ background: 'var(--muted)' }}>
                    <AlertTriangle className="w-4 h-4" style={{ color: 'var(--destructive)' }} />
                    <span className="text-sm" style={{ color: 'var(--foreground)' }}>
                      Renewing soon! Pause if not needed
                    </span>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={() => onPause(sub.id)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </Button>
                  <Button
                    onClick={() => onCancel(sub.id)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    style={{ borderColor: 'var(--destructive)', color: 'var(--destructive)' }}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {pausedSubscriptions.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="space-y-3"
        >
          <h3 className="font-medium" style={{ color: 'var(--foreground)' }}>Paused</h3>
          {pausedSubscriptions.map((sub, index) => (
            <motion.div
              key={sub.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className="rounded-lg p-4 opacity-60"
              style={{ background: 'var(--card)' }}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="text-3xl grayscale">{sub.icon}</div>
                  <div>
                    <div className="font-medium" style={{ color: 'var(--foreground)' }}>
                      {sub.name}
                    </div>
                    <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
                      ₹{sub.amount}/month
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => onResume(sub.id)}
                  size="sm"
                  className="flex-1"
                  style={{ background: 'var(--secondary)', color: 'var(--secondary-foreground)' }}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Resume
                </Button>
                <Button
                  onClick={() => onCancel(sub.id)}
                  variant="outline"
                  size="sm"
                  style={{ borderColor: 'var(--destructive)', color: 'var(--destructive)' }}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}

      {subscriptions.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12 rounded-lg"
          style={{ background: 'var(--card)' }}
        >
          <Clock className="w-12 h-12 mx-auto mb-3" style={{ color: 'var(--muted-foreground)' }} />
          <div className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>No subscriptions tracked</div>
          <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            AI will detect recurring payments automatically
          </div>
        </motion.div>
      )}
    </div>
  );
}
