# 🧾 Bill Splitter Feature - Splitwise Integration

## Overview

The Bill Splitter feature helps students track shared expenses with friends, just like Splitwise. After a group transaction (dinner, cab ride, movie tickets), the money is automatically split among participants with smart settlement suggestions.

## ✨ Key Features

### 1. **Add Friends to Your Group**
- Create a friend list with just their names
- Each friend gets a unique avatar based on their first letter
- Unlimited friends can be added

### 2. **Split Bills Automatically**
- Enter expense details (description, total amount, who paid)
- Select which friends to split with
- Choose equal split or custom amounts
- Instantly calculates per-person cost

### 3. **Track Who Owes Whom**
- Real-time balance calculations
- Shows total amount you're owed
- Shows total amount you owe
- Visual cards with clear breakdown

### 4. **Smart Settlement Suggestions**
- AI minimizes number of transactions needed
- Shows exactly who should pay whom
- Optimal settlement paths (e.g., A → B → C becomes A → C)
- Clear visual arrows showing money flow

### 5. **Settle Up Functionality**
- Mark individual participants as "settled"
- One-click settlement for each person
- Track payment history
- Balances update automatically

### 6. **Expense History**
- View all split expenses by date
- See who paid and who participated
- Track settled vs unsettled amounts
- Category-wise organization

## 🎨 User Interface

### Dashboard Cards
```
┌─────────────────────────────────────────────────┐
│ You're Owed    │ You Owe       │ Total Splits   │
│ ₹400           │ ₹150          │ 5              │
│ 🔻 (green)     │ 🔺 (red)      │ 👥 (purple)    │
└─────────────────────────────────────────────────┘
```

### Suggested Settlements
```
Rahul → You: ₹200
You → Priya: ₹150
Amit → Rahul: ₹100
```

### Split Expense Card
```
┌─────────────────────────────────────────────────┐
│ Dinner at Pizza Hut            ₹800             │
│ Paid by You • Apr 8                             │
│                                                  │
│ 👤 You        ₹200  [Paid]                      │
│ 👤 Rahul      ₹200  [Settle] ←                  │
│ 👤 Priya      ₹200  ✓ Settled                   │
│ 👤 Amit       ₹200  [Settle] ←                  │
└─────────────────────────────────────────────────┘
```

## 📱 How to Use

### Web App (React)

1. **Navigate to Bill Splitter**
   - Click on "Bill Splitter" in the sidebar
   - You'll see the overview with balances

2. **Add Friends**
   - Click "Add Friend" button
   - Enter friend's name
   - Click "Add Friend" to confirm

3. **Split a Bill**
   - Click "Split Bill" button
   - Fill in details:
     - Description (e.g., "Dinner at Pizza Hut")
     - Total amount (e.g., 800)
     - Who paid (You or a friend)
     - Select participants by clicking their names
   - Choose "Equal Split" or "Custom Split"
   - Click "Split Bill" to create

4. **Settle Payments**
   - Find the expense in the list
   - Click "Settle" next to each participant's name
   - Their status changes to "Settled"
   - Balances update automatically

### Android App

1. **Navigate to Bill Splitter**
   - Open navigation drawer (☰)
   - Tap "Bill Splitter"

2. **Add Friends**
   - Tap "Add Friend" button (top right)
   - Enter friend's name in dialog
   - Tap "Add" to confirm

3. **Split a Bill**
   - Tap "Split Bill" button
   - Fill in the form:
     - Description
     - Total amount (₹)
     - Select participants (tap chips to toggle)
   - Equal split is calculated automatically
   - Tap "Split Bill" to create

4. **Settle Payments**
   - Open an expense card
   - Tap "Settle" button next to participant
   - Toast confirms settlement
   - Card updates to show "Settled" status

## 💡 Smart Features

### Balance Calculation Algorithm

The app uses a sophisticated algorithm to calculate who owes whom:

```
For each expense:
  For each participant:
    If participant paid:
      Balance += (Total - Their Share)
    Else:
      Balance -= Their Share
```

### Settlement Optimization

Instead of everyone paying the person who paid:
- **Bad**: A pays B ₹100, C pays B ₹100, D pays B ₹100
- **Good**: Uses graph algorithm to minimize transactions

Example:
```
Before optimization:
- Rahul owes You ₹200
- You owe Priya ₹150
- Amit owes Rahul ₹100

After optimization:
- Rahul owes You ₹50
- Amit owes You ₹100
- You owe Priya ₹150
```

## 📊 Sample Data

The app comes with pre-loaded sample data:

### Sample Friends
- Rahul
- Priya
- Amit
- Neha

### Sample Split Expenses

1. **Dinner at Pizza Hut** (₹800)
   - Paid by: You
   - Split among: You, Rahul, Priya, Amit
   - ₹200 each
   - Priya: Settled ✓

2. **Uber to College** (₹150)
   - Paid by: Rahul
   - Split among: You, Rahul, Neha
   - ₹50 each
   - Neha: Settled ✓

3. **Movie Tickets** (₹600)
   - Paid by: Priya
   - Split among: You, Priya, Rahul, Amit
   - ₹150 each
   - You: Settled ✓

## 🎯 Use Cases for Students

### 1. **Canteen Meals**
```
Scenario: 4 friends have lunch together
One person pays ₹320 for everyone
Each owes ₹80
```

### 2. **Cab/Uber Rides**
```
Scenario: 3 friends share a cab to college
One books the ride for ₹150
Each owes ₹50
```

### 3. **Movie/Entertainment**
```
Scenario: Group movie outing
One person books all tickets
Bill is split equally
```

### 4. **Group Shopping**
```
Scenario: Buying supplies together
Track who paid for what
Settle at the end of the month
```

### 5. **Subscription Sharing**
```
Scenario: Split Netflix/Spotify family plan
One person pays monthly
Others settle their share
```

## 🔄 Data Flow

```
User Action → Component → State Update → Storage → UI Update
```

### React Web App
```javascript
User clicks "Split Bill"
  ↓
BillSplitter component shows dialog
  ↓
User fills form and submits
  ↓
handleAddSplitExpense() called
  ↓
State updates (setSplitExpenses)
  ↓
useEffect saves to localStorage
  ↓
UI re-renders with new expense
```

### Android App
```kotlin
User taps "Split Bill"
  ↓
AddExpenseDialog shows
  ↓
User fills form and taps "Split Bill"
  ↓
viewModel.addSplitExpense() called
  ↓
AppState updates via StateFlow
  ↓
ViewModel saves to SharedPreferences
  ↓
Compose re-renders with new expense
```

## 🎨 Color Coding

- **Positive Balance (Owed to you)**: Teal (`#03DAC6`) - Secondary color
- **Negative Balance (You owe)**: Muted Rose (`#CF6679`) - Destructive color
- **Settled Status**: Teal (`#03DAC6`) - Success indicator
- **Unsettled Status**: Purple (`#BB86FC`) - Primary color for action buttons

## 🔮 Future Enhancements

Potential features for production version:

1. **Receipt Scanning**
   - OCR to auto-fill amount and vendor
   - AI categorization from receipt image

2. **Payment Integration**
   - Direct UPI payment links
   - Google Pay / PhonePe integration
   - One-tap settlement

3. **Recurring Splits**
   - Set up monthly rent splits
   - Auto-split subscription renewals
   - Weekly grocery splits

4. **Group Management**
   - Create named groups (Roommates, College Squad, etc.)
   - Group-specific expense tracking
   - Group totals and statistics

5. **Reminders**
   - Push notifications for unsettled amounts
   - Gentle payment reminders
   - Monthly settlement summaries

6. **Analytics**
   - Spending patterns with each friend
   - Most frequent split categories
   - Average group expense size

7. **Export**
   - Export to Excel/CSV
   - Share expense reports
   - PDF summary generation

## 🔧 Technical Implementation

### React (Web)

**Key Files:**
- `src/app/components/BillSplitter.tsx` - Main component
- `src/app/App.tsx` - Integration and state management
- Uses React hooks (useState, useEffect)
- Motion/Framer for animations

**State Management:**
```typescript
interface SplitExpense {
  id: string;
  description: string;
  totalAmount: number;
  paidBy: string;
  date: Date;
  participants: Participant[];
  category: string;
}
```

### Android (Kotlin)

**Key Files:**
- `BillSplitterScreen.kt` - Main composable
- `Models.kt` - Data classes
- `SpendSenseViewModel.kt` - State management
- Uses Jetpack Compose
- StateFlow for reactive state

**State Management:**
```kotlin
data class SplitExpense(
    val id: String,
    val description: String,
    val totalAmount: Double,
    val paidBy: String,
    val date: Date,
    val category: String,
    val participants: List<Participant>
)
```

## 🎓 Educational Value

This feature teaches students:

1. **Financial Responsibility**
   - Track shared expenses
   - Settle debts promptly
   - Maintain clear records

2. **Friendship Management**
   - Avoid money-related conflicts
   - Transparent expense sharing
   - Fair cost distribution

3. **Budgeting Skills**
   - Understand group spending
   - Plan shared activities
   - Manage peer expenses

## 📝 Testing the Feature

### Quick Test Scenarios

1. **Add a friend named "Test User"**
   - Verify they appear in friend list
   - Check avatar is "T"

2. **Create a split expense**
   - Add ₹500 dinner
   - Split with 3 people
   - Verify ₹166.67 per person (or ₹167)

3. **Check balance calculations**
   - You paid ₹500, owe ₹166.67
   - You're owed: ₹333.33
   - Verify dashboard shows this

4. **Settle one person**
   - Click "Settle" on one participant
   - Verify balance decreases by their share
   - Check "Settled" badge appears

5. **View suggested settlements**
   - Create multiple expenses
   - Check optimization works
   - Verify arrows show correct direction

## 🚀 Summary

The Bill Splitter feature is a complete Splitwise-like solution integrated into SpendSense, helping students:

✅ Track group expenses effortlessly
✅ Split bills automatically
✅ Minimize settlement transactions
✅ Avoid money conflicts with friends
✅ Maintain transparent expense records

**Perfect for students who frequently share costs with friends and roommates!** 🎉

---

**Built with the same design language and color scheme as the rest of SpendSense!**
