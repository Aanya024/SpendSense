package com.spendsense.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.spendsense.app.data.Friend
import com.spendsense.app.data.SplitExpense
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillSplitterScreen(
    friends: List<Friend>,
    splitExpenses: List<SplitExpense>,
    onAddFriend: (String) -> Unit,
    onAddExpense: (SplitExpense) -> Unit,
    onSettleUp: (String, String) -> Unit
) {
    var showAddFriendDialog by remember { mutableStateOf(false) }
    var showAddExpenseDialog by remember { mutableStateOf(false) }

    val balances = remember(splitExpenses) {
        val balanceMap = mutableMapOf<String, Double>("You" to 0.0)
        friends.forEach { balanceMap[it.name] = 0.0 }

        splitExpenses.forEach { expense ->
            expense.participants.forEach { participant ->
                if (!participant.settled) {
                    if (participant.name == expense.paidBy) {
                        balanceMap[participant.name] = (balanceMap[participant.name] ?: 0.0) +
                            (expense.totalAmount - participant.amount)
                    } else {
                        balanceMap[participant.name] = (balanceMap[participant.name] ?: 0.0) -
                            participant.amount
                    }
                }
            }
        }
        balanceMap
    }

    val totalOwed = balances.values.filter { it > 0.01 }.sum()
    val totalOwe = balances.values.filter { it < -0.01 }.sumOf { kotlin.math.abs(it) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Bill Splitter",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Split expenses with friends automatically",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(onClick = { showAddFriendDialog = true }) {
                    Icon(Icons.Default.PersonAdd, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Add Friend")
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "You're Owed",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Icon(
                                Icons.Default.TrendingDown,
                                null,
                                Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "₹${totalOwed.toInt()}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "You Owe",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Icon(
                                Icons.Default.TrendingUp,
                                null,
                                Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "₹${totalOwe.toInt()}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Recent Splits",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Button(onClick = { showAddExpenseDialog = true }) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Split Bill")
                }
            }
        }

        if (splitExpenses.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Group,
                            null,
                            Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "No split bills yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Add friends and start splitting expenses",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        items(splitExpenses) { expense ->
            SplitExpenseCard(
                expense = expense,
                onSettleUp = { participantId -> onSettleUp(expense.id, participantId) }
            )
        }
    }

    if (showAddFriendDialog) {
        AddFriendDialog(
            onDismiss = { showAddFriendDialog = false },
            onConfirm = { name ->
                onAddFriend(name)
                showAddFriendDialog = false
            }
        )
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            friends = friends,
            onDismiss = { showAddExpenseDialog = false },
            onConfirm = { expense ->
                onAddExpense(expense)
                showAddExpenseDialog = false
            }
        )
    }
}

@Composable
fun SplitExpenseCard(
    expense: SplitExpense,
    onSettleUp: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        expense.description,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Paid by ${expense.paidBy} • ${SimpleDateFormat("MMM dd", Locale.getDefault()).format(expense.date)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                </div>
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        "₹${expense.totalAmount.toInt()}",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${expense.participants.size} people",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            expense.participants.forEach { participant ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier.size(24.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        participant.name.first().toString(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                            Text(
                                participant.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "₹${participant.amount.toInt()}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            when {
                                participant.settled -> {
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondary,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            "Settled",
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSecondary
                                        )
                                    }
                                }
                                participant.name != expense.paidBy -> {
                                    TextButton(onClick = { onSettleUp(participant.id) }) {
                                        Text("Settle")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFriendDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var friendName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Friend") },
        text = {
            OutlinedTextField(
                value = friendName,
                onValueChange = { friendName = it },
                label = { Text("Friend's Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { if (friendName.isNotBlank()) onConfirm(friendName) },
                enabled = friendName.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    friends: List<Friend>,
    onDismiss: () -> Unit,
    onConfirm: (SplitExpense) -> Unit
) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paidBy by remember { mutableStateOf("You") }
    var selectedFriends by remember { mutableStateOf(setOf("You")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Split a Bill") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    placeholder = { Text("e.g., Dinner at Pizza Hut") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Total Amount (₹)") },
                    leadingIcon = { Text("₹") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("Split with:", style = MaterialTheme.typography.bodyMedium)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFriends.contains("You"),
                        onClick = {
                            selectedFriends = if (selectedFriends.contains("You")) {
                                if (selectedFriends.size > 1) selectedFriends - "You" else selectedFriends
                            } else {
                                selectedFriends + "You"
                            }
                        },
                        label = { Text("You") }
                    )

                    friends.forEach { friend ->
                        FilterChip(
                            selected = selectedFriends.contains(friend.name),
                            onClick = {
                                selectedFriends = if (selectedFriends.contains(friend.name)) {
                                    selectedFriends - friend.name
                                } else {
                                    selectedFriends + friend.name
                                }
                            },
                            label = { Text(friend.name) }
                        )
                    }
                }

                if (amount.isNotBlank() && selectedFriends.isNotEmpty()) {
                    val perPerson = amount.toDoubleOrNull()?.div(selectedFriends.size) ?: 0.0
                    Text(
                        "Each person pays: ₹${perPerson.toInt()}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (description.isNotBlank() && amount.isNotBlank() && selectedFriends.isNotEmpty()) {
                        val totalAmount = amount.toDoubleOrNull() ?: 0.0
                        val perPerson = totalAmount / selectedFriends.size

                        val expense = SplitExpense(
                            id = System.currentTimeMillis().toString(),
                            description = description,
                            totalAmount = totalAmount,
                            paidBy = paidBy,
                            date = Date(),
                            category = "Split",
                            participants = selectedFriends.map { name ->
                                SplitExpense.Participant(
                                    id = if (name == "You") "you" else friends.find { it.name == name }?.id ?: "",
                                    name = name,
                                    amount = perPerson,
                                    settled = false
                                )
                            }
                        )
                        onConfirm(expense)
                    }
                },
                enabled = description.isNotBlank() && amount.isNotBlank() && selectedFriends.isNotEmpty()
            ) {
                Text("Split Bill")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    content: @Composable () -> Unit
) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = modifier,
        horizontalArrangement = horizontalArrangement,
        content = content
    )
}
