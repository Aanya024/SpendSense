package com.spendsense.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Primary,
    onPrimary = Background,
    secondary = Secondary,
    onSecondary = Background,
    background = Background,
    onBackground = Foreground,
    surface = CardBackground,
    onSurface = Foreground,
    error = Destructive,
    onError = Foreground,
    outline = Border,
    surfaceVariant = Muted,
    onSurfaceVariant = MutedForeground
)

@Composable
fun SpendSenseTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
