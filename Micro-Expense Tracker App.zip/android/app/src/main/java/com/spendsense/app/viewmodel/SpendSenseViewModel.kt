package com.spendsense.app.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.spendsense.app.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.*

class SpendSenseViewModel(application: Application) : AndroidViewModel(application) {
    private val _appState = MutableStateFlow(AppState())
    val appState: StateFlow<AppState> = _appState

    private val prefs = application.getSharedPreferences("spendsense", Context.MODE_PRIVATE)
    private val gson = Gson()

    init {
        loadData()
    }

    private fun loadData() {
        val saved = prefs.getString("app_state", null)
        if (saved != null) {
            try {
                _appState.value = gson.fromJson(saved, AppState::class.java)
            } catch (e: Exception) {
                loadSampleData()
            }
        } else {
            loadSampleData()
        }
    }

    private fun saveData() {
        viewModelScope.launch {
            prefs.edit().putString("app_state", gson.toJson(_appState.value)).apply()
        }
    }

    fun completeOnboarding(budgets: List<BudgetCategory>, income: Double) {
        _appState.value = _appState.value.copy(
            isOnboarded = true,
            budgets = budgets,
            totalIncome = income
        )
        saveData()
    }

    fun addRandomTransaction() {
        val vendors = listOf("Starbucks", "McDonald's", "Ola", "Myntra", "BigBasket")
        val categories = listOf("Food", "Transport", "Shopping", "Entertainment", "Other")
        val vendor = vendors.random()
        val category = categories.random()
        val amount = (50..500).random().toDouble()

        val transaction = Transaction(
            id = UUID.randomUUID().toString(),
            vendor = vendor,
            amount = amount,
            category = category,
            date = Date(),
            aiParsed = true,
            rawText = "Payment of Rs.$amount to $vendor via UPI"
        )

        _appState.value = _appState.value.copy(
            transactions = listOf(transaction) + _appState.value.transactions
        )
        saveData()
    }

    fun pauseSubscription(id: String) {
        val updated = _appState.value.subscriptions.map {
            if (it.id == id) it.copy(status = SubscriptionStatus.PAUSED) else it
        }
        _appState.value = _appState.value.copy(subscriptions = updated)
        saveData()
    }

    fun resumeSubscription(id: String) {
        val updated = _appState.value.subscriptions.map {
            if (it.id == id) it.copy(status = SubscriptionStatus.ACTIVE) else it
        }
        _appState.value = _appState.value.copy(subscriptions = updated)
        saveData()
    }

    fun cancelSubscription(id: String) {
        val updated = _appState.value.subscriptions.filter { it.id != id }
        _appState.value = _appState.value.copy(subscriptions = updated)
        saveData()
    }

    fun addFriend(name: String) {
        val newFriend = Friend(
            id = UUID.randomUUID().toString(),
            name = name,
            avatar = name.first().toString()
        )
        _appState.value = _appState.value.copy(
            friends = _appState.value.friends + newFriend
        )
        saveData()
    }

    fun addSplitExpense(expense: SplitExpense) {
        _appState.value = _appState.value.copy(
            splitExpenses = listOf(expense) + _appState.value.splitExpenses
        )
        saveData()
    }

    fun settleUpExpense(expenseId: String, participantId: String) {
        val updated = _appState.value.splitExpenses.map { expense ->
            if (expense.id == expenseId) {
                expense.copy(
                    participants = expense.participants.map { participant ->
                        if (participant.id == participantId) {
                            participant.copy(settled = true)
                        } else {
                            participant
                        }
                    }
                )
            } else {
                expense
            }
        }
        _appState.value = _appState.value.copy(splitExpenses = updated)
        saveData()
    }

    private fun loadSampleData() {
        val calendar = Calendar.getInstance()

        val transactions = listOf(
            Transaction("1", "Zomato", 250.0, "Food", Date(), true, "Your order from Pizza Hut via Zomato for Rs.250 has been delivered"),
            Transaction("2", "Uber", 120.0, "Transport", Date(System.currentTimeMillis() - 86400000), true, "You paid Rs.120 for your Uber ride"),
            Transaction("3", "BookMyShow", 300.0, "Entertainment", Date(System.currentTimeMillis() - 172800000), true, "Booking confirmed! 2 tickets - Rs.300"),
            Transaction("4", "Amazon", 450.0, "Shopping", Date(System.currentTimeMillis() - 259200000), false),
            Transaction("5", "Swiggy", 180.0, "Food", Date(System.currentTimeMillis() - 345600000), true, "Swiggy: Your order from Dominos Rs.180"),
            Transaction("6", "Metro Card", 50.0, "Transport", Date(System.currentTimeMillis() - 432000000), true, "Metro card recharge - Rs.50"),
            Transaction("7", "Cafe Coffee Day", 200.0, "Food", Date(System.currentTimeMillis() - 518400000), false),
            Transaction("8", "Flipkart", 350.0, "Shopping", Date(System.currentTimeMillis() - 604800000), true, "Your Flipkart order for Rs.350 dispatched")
        )

        calendar.add(Calendar.DAY_OF_MONTH, 7)
        val subscriptions = listOf(
            Subscription("1", "Netflix", 199.0, calendar.time, SubscriptionStatus.ACTIVE, "🎬"),
            Subscription("2", "Spotify", 119.0, Date(calendar.timeInMillis + 432000000), SubscriptionStatus.ACTIVE, "🎵"),
            Subscription("3", "Amazon Prime", 129.0, Date(calendar.timeInMillis - 172800000), SubscriptionStatus.ACTIVE, "📦"),
            Subscription("4", "YouTube Premium", 89.0, Date(calendar.timeInMillis + 2592000000), SubscriptionStatus.PAUSED, "📺")
        )

        val friends = listOf(
            Friend("1", "Rahul", "R"),
            Friend("2", "Priya", "P"),
            Friend("3", "Amit", "A"),
            Friend("4", "Neha", "N")
        )

        val splitExpenses = listOf(
            SplitExpense(
                id = "1",
                description = "Dinner at Pizza Hut",
                totalAmount = 800.0,
                paidBy = "You",
                date = Date(),
                category = "Split",
                participants = listOf(
                    SplitExpense.Participant("you", "You", 200.0, false),
                    SplitExpense.Participant("1", "Rahul", 200.0, false),
                    SplitExpense.Participant("2", "Priya", 200.0, true),
                    SplitExpense.Participant("3", "Amit", 200.0, false)
                )
            ),
            SplitExpense(
                id = "2",
                description = "Uber to College",
                totalAmount = 150.0,
                paidBy = "Rahul",
                date = Date(System.currentTimeMillis() - 86400000),
                category = "Split",
                participants = listOf(
                    SplitExpense.Participant("you", "You", 50.0, false),
                    SplitExpense.Participant("1", "Rahul", 50.0, false),
                    SplitExpense.Participant("4", "Neha", 50.0, true)
                )
            ),
            SplitExpense(
                id = "3",
                description = "Movie Tickets",
                totalAmount = 600.0,
                paidBy = "Priya",
                date = Date(System.currentTimeMillis() - 259200000),
                category = "Split",
                participants = listOf(
                    SplitExpense.Participant("you", "You", 150.0, true),
                    SplitExpense.Participant("2", "Priya", 150.0, false),
                    SplitExpense.Participant("1", "Rahul", 150.0, false),
                    SplitExpense.Participant("3", "Amit", 150.0, false)
                )
            )
        )

        _appState.value = _appState.value.copy(
            transactions = transactions,
            subscriptions = subscriptions,
            friends = friends,
            splitExpenses = splitExpenses
        )
    }
}
