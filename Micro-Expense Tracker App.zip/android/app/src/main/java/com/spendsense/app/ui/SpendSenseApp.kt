package com.spendsense.app.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.spendsense.app.ui.screens.*
import com.spendsense.app.viewmodel.SpendSenseViewModel

enum class Screen {
    DASHBOARD, FORECAST, TRANSACTIONS, SPLIT, SUBSCRIPTIONS, CHAT
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpendSenseApp(
    viewModel: SpendSenseViewModel = viewModel()
) {
    val appState by viewModel.appState.collectAsState()
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(Screen.DASHBOARD) }
    var drawerOpen by remember { mutableStateOf(false) }

    if (!appState.isOnboarded) {
        OnboardingScreen(
            onComplete = { budgets, income ->
                viewModel.completeOnboarding(budgets, income)
                Toast.makeText(
                    context,
                    "Welcome to SpendSense! Your AI assistant is ready.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    } else {
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

        LaunchedEffect(drawerOpen) {
            if (drawerOpen) drawerState.open() else drawerState.close()
        }

        LaunchedEffect(drawerState.currentValue) {
            drawerOpen = drawerState.currentValue == DrawerValue.Open
        }

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = MaterialTheme.colorScheme.surface
                ) {
                    NavigationDrawerContent(
                        currentScreen = currentScreen,
                        onScreenSelected = { screen ->
                            currentScreen = screen
                            drawerOpen = false
                        }
                    )
                }
            }
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("SpendSense") },
                        navigationIcon = {
                            IconButton(onClick = { drawerOpen = !drawerOpen }) {
                                Icon(Icons.Default.Menu, "Menu")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.primary
                        )
                    )
                },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = {
                            viewModel.addRandomTransaction()
                            Toast.makeText(context, "Transaction added by AI", Toast.LENGTH_SHORT).show()
                        },
                        containerColor = MaterialTheme.colorScheme.secondary
                    ) {
                        Icon(Icons.Default.Add, "Add Transaction")
                    }
                }
            ) { paddingValues ->
                Box(modifier = Modifier.padding(paddingValues)) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(300)) with
                                    fadeOut(animationSpec = tween(300))
                        },
                        label = "screen_transition"
                    ) { screen ->
                        when (screen) {
                            Screen.DASHBOARD -> DashboardScreen(
                                budgets = appState.budgets,
                                transactions = appState.transactions,
                                totalIncome = appState.totalIncome
                            )
                            Screen.FORECAST -> PredictiveBudgetScreen(
                                budgets = appState.budgets,
                                transactions = appState.transactions,
                                totalIncome = appState.totalIncome
                            )
                            Screen.TRANSACTIONS -> TransactionListScreen(
                                transactions = appState.transactions
                            )
                            Screen.SPLIT -> BillSplitterScreen(
                                friends = appState.friends,
                                splitExpenses = appState.splitExpenses,
                                onAddFriend = { name ->
                                    viewModel.addFriend(name)
                                    Toast.makeText(context, "$name added to your group!", Toast.LENGTH_SHORT).show()
                                },
                                onAddExpense = { expense ->
                                    viewModel.addSplitExpense(expense)
                                    Toast.makeText(context, "Expense split successfully!", Toast.LENGTH_SHORT).show()
                                },
                                onSettleUp = { expenseId, participantId ->
                                    viewModel.settleUpExpense(expenseId, participantId)
                                    Toast.makeText(context, "Payment settled!", Toast.LENGTH_SHORT).show()
                                }
                            )
                            Screen.SUBSCRIPTIONS -> SubscriptionTrackerScreen(
                                subscriptions = appState.subscriptions,
                                onPause = { id ->
                                    viewModel.pauseSubscription(id)
                                    Toast.makeText(context, "Subscription paused", Toast.LENGTH_SHORT).show()
                                },
                                onResume = { id ->
                                    viewModel.resumeSubscription(id)
                                    Toast.makeText(context, "Subscription resumed", Toast.LENGTH_SHORT).show()
                                },
                                onCancel = { id ->
                                    viewModel.cancelSubscription(id)
                                    Toast.makeText(context, "Subscription cancelled", Toast.LENGTH_SHORT).show()
                                }
                            )
                            Screen.CHAT -> ChatbotScreen(
                                transactions = appState.transactions,
                                budgets = appState.budgets,
                                totalIncome = appState.totalIncome
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NavigationDrawerContent(
    currentScreen: Screen,
    onScreenSelected: (Screen) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SpendSense",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(vertical = 16.dp)
        )
        Text(
            text = "Stop Financial Leaking",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Dashboard, null) },
            label = { Text("Dashboard") },
            selected = currentScreen == Screen.DASHBOARD,
            onClick = { onScreenSelected(Screen.DASHBOARD) },
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                selectedIconColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.TrendingUp, null) },
            label = { Text("AI Forecast") },
            selected = currentScreen == Screen.FORECAST,
            onClick = { onScreenSelected(Screen.FORECAST) },
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                selectedIconColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Receipt, null) },
            label = { Text("Transactions") },
            selected = currentScreen == Screen.TRANSACTIONS,
            onClick = { onScreenSelected(Screen.TRANSACTIONS) },
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                selectedIconColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Group, null) },
            label = { Text("Bill Splitter") },
            selected = currentScreen == Screen.SPLIT,
            onClick = { onScreenSelected(Screen.SPLIT) },
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                selectedIconColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.CreditCard, null) },
            label = { Text("Subscriptions") },
            selected = currentScreen == Screen.SUBSCRIPTIONS,
            onClick = { onScreenSelected(Screen.SUBSCRIPTIONS) },
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                selectedIconColor = MaterialTheme.colorScheme.onPrimary
            )
        )

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Chat, null) },
            label = { Text("AI Chat") },
            selected = currentScreen == Screen.CHAT,
            onClick = { onScreenSelected(Screen.CHAT) },
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                selectedIconColor = MaterialTheme.colorScheme.onPrimary
            )
        )
    }
}
