package com.spendsense.app.data

import java.util.Date

data class BudgetCategory(
    val name: String,
    var amount: Double,
    val icon: String,
    var spent: Double = 0.0
)

data class Transaction(
    val id: String,
    val vendor: String,
    val amount: Double,
    val category: String,
    val date: Date,
    val aiParsed: Boolean,
    val rawText: String? = null
)

data class Subscription(
    val id: String,
    val name: String,
    val amount: Double,
    val renewalDate: Date,
    var status: SubscriptionStatus,
    val icon: String
)

enum class SubscriptionStatus {
    ACTIVE, PAUSED
}

data class Friend(
    val id: String,
    val name: String,
    val avatar: String
)

data class SplitExpense(
    val id: String,
    val description: String,
    val totalAmount: Double,
    val paidBy: String,
    val date: Date,
    val category: String,
    val participants: List<Participant>
) {
    data class Participant(
        val id: String,
        val name: String,
        val amount: Double,
        var settled: Boolean
    )
}

data class AppState(
    val isOnboarded: Boolean = false,
    val budgets: List<BudgetCategory> = emptyList(),
    val totalIncome: Double = 5000.0,
    val transactions: List<Transaction> = emptyList(),
    val subscriptions: List<Subscription> = emptyList(),
    val friends: List<Friend> = emptyList(),
    val splitExpenses: List<SplitExpense> = emptyList()
)
