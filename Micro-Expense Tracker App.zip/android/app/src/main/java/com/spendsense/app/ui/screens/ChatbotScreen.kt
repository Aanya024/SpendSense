package com.spendsense.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.spendsense.app.data.BudgetCategory
import com.spendsense.app.data.Transaction
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Date = Date()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotScreen(
    transactions: List<Transaction>,
    budgets: List<BudgetCategory>,
    totalIncome: Double
) {
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    "1",
                    "Hi! I'm your AI finance assistant. I can help you understand your spending patterns, give budget advice, or answer questions about your transactions. What would you like to know?",
                    false
                )
            )
        )
    }
    var inputText by remember { mutableStateOf("") }
    var isTyping by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    fun generateBotResponse(userMessage: String): String {
        val msg = userMessage.lowercase()
        val totalSpent = transactions.sumOf { it.amount }
        val remaining = totalIncome - totalSpent

        return when {
            msg.contains("spent") || msg.contains("spending") -> {
                "You've spent ₹${totalSpent.toInt()} so far this month, which is ${((totalSpent / totalIncome) * 100).toInt()}% of your allowance. You have ₹${remaining.toInt()} remaining."
            }
            msg.contains("food") || msg.contains("eat") -> {
                val foodBudget = budgets.find { it.name == "Food" }
                val foodSpent = transactions.filter { it.category == "Food" }.sumOf { it.amount }
                "Your food budget is ₹${foodBudget?.amount?.toInt() ?: 0}, and you've spent ₹${foodSpent.toInt()} so far. ${
                    if (foodSpent > (foodBudget?.amount ?: 0.0) * 0.8)
                        "You're nearing your limit! Consider cooking at home to save money."
                    else
                        "You're doing well with your food expenses!"
                }"
            }
            msg.contains("save") || msg.contains("saving") -> {
                "Based on your current spending rate, you could save ₹${remaining.toInt()} this month. To save more, I suggest reducing spending in categories where you've exceeded 80% of your budget."
            }
            msg.contains("suggest") || msg.contains("advice") || msg.contains("tip") -> {
                val overBudget = budgets.filter { budget ->
                    val spent = transactions.filter { it.category == budget.name }.sumOf { it.amount }
                    spent > budget.amount * 0.8
                }
                if (overBudget.isNotEmpty()) {
                    "You're spending heavily on ${overBudget[0].name}. Try setting daily limits or finding cheaper alternatives to stay within budget."
                } else {
                    "You're managing your budget well! Keep tracking your expenses and you'll avoid financial leaking."
                }
            }
            msg.contains("transaction") || msg.contains("recent") -> {
                val recent = transactions.take(3)
                if (recent.isEmpty()) {
                    "You don't have any transactions yet."
                } else {
                    val list = recent.joinToString(", ") { "₹${it.amount.toInt()} at ${it.vendor} (${it.category})" }
                    "Your recent transactions: $list"
                }
            }
            msg.contains("budget") -> {
                val total = budgets.sumOf { it.amount }
                val biggest = budgets.maxByOrNull { it.amount }
                "Your total monthly budget is ₹${total.toInt()}. The biggest allocation is for ${biggest?.name} at ₹${biggest?.amount?.toInt()}."
            }
            msg.contains("hello") || msg.contains("hi") || msg.contains("hey") -> {
                "Hello! How can I help you manage your finances today?"
            }
            else -> {
                "I can help you with spending analysis, budget advice, transaction history, and savings tips. What would you like to know?"
            }
        }
    }

    fun sendMessage() {
        if (inputText.isBlank()) return

        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            text = inputText,
            isUser = true
        )

        messages = messages + userMessage
        val userInput = inputText
        inputText = ""
        isTyping = true

        coroutineScope.launch {
            listState.animateScrollToItem(messages.size)
            delay(1000L + (Math.random() * 1000).toLong())

            val botResponse = ChatMessage(
                id = UUID.randomUUID().toString(),
                text = generateBotResponse(userInput),
                isUser = false
            )

            messages = messages + botResponse
            isTyping = false
            listState.animateScrollToItem(messages.size)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.SmartToy,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }

            Column {
                Text(
                    text = "AI Assistant",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Always here to help",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { message ->
                MessageBubble(message = message)
            }

            if (isTyping) {
                item {
                    TypingIndicator()
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask about your spending...") },
                singleLine = true
            )

            Button(
                onClick = { sendMessage() },
                enabled = inputText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!message.isUser) {
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.SmartToy,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Card(
            modifier = Modifier.widthIn(max = 280.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (message.isUser)
                    MaterialTheme.colorScheme.primary
                else
                    MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(
                topStart = if (message.isUser) 16.dp else 4.dp,
                topEnd = if (message.isUser) 4.dp else 16.dp,
                bottomStart = 16.dp,
                bottomEnd = 16.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (message.isUser)
                        MaterialTheme.colorScheme.onPrimary
                    else
                        MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(message.timestamp),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (message.isUser)
                        MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
                    else
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (message.isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Default.Person,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun TypingIndicator() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Default.SmartToy,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))

        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                repeat(3) { index ->
                    Surface(
                        modifier = Modifier.size(8.dp),
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.primary.copy(
                            alpha = 0.4f + (index * 0.2f)
                        )
                    ) {}
                }
            }
        }
    }
}
