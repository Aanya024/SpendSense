package com.spendsense.app.ui.theme

import androidx.compose.ui.graphics.Color

// SpendSense Color Palette
val Background = Color(0xFF121212)         // Deep Charcoal
val Foreground = Color(0xFFE0E0E0)         // Light Grey
val CardBackground = Color(0xFF1E1E1E)     // Lighter Grey (Surface)
val Primary = Color(0xFFBB86FC)            // Soft Purple
val Secondary = Color(0xFF03DAC6)          // Teal
val Destructive = Color(0xFFCF6679)        // Muted Rose
val Muted = Color(0xFF2A2A2A)              // Darker Grey
val MutedForeground = Color(0xFF9E9E9E)    // Medium Grey
val Border = Color(0xFF2A2A2A)             // Border Color
