package com.spendsense.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.spendsense.app.data.BudgetCategory

@Composable
fun OnboardingScreen(
    onComplete: (List<BudgetCategory>, Double) -> Unit
) {
    var step by remember { mutableStateOf(0) }
    var monthlyIncome by remember { mutableStateOf("") }
    var budgets by remember {
        mutableStateOf(
            listOf(
                BudgetCategory("Food", 0.0, "🍔"),
                BudgetCategory("Transport", 0.0, "🚌"),
                BudgetCategory("Entertainment", 0.0, "🎬"),
                BudgetCategory("Shopping", 0.0, "🛍️"),
                BudgetCategory("Other", 0.0, "📦")
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                slideInHorizontally(
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                ) { it } with slideOutHorizontally { -it }
            },
            label = "step_transition"
        ) { currentStep ->
            when (currentStep) {
                0 -> Step1(
                    monthlyIncome = monthlyIncome,
                    onIncomeChange = { monthlyIncome = it },
                    onNext = { step = 1 }
                )
                1 -> Step2(
                    budgets = budgets,
                    totalIncome = monthlyIncome.toDoubleOrNull() ?: 0.0,
                    onBudgetChange = { index, amount ->
                        budgets = budgets.toMutableList().apply {
                            this[index] = this[index].copy(amount = amount)
                        }
                    },
                    onComplete = {
                        onComplete(budgets, monthlyIncome.toDoubleOrNull() ?: 5000.0)
                    }
                )
            }
        }
    }
}

@Composable
fun Step1(
    monthlyIncome: String,
    onIncomeChange: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Default.AccountBalanceWallet,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Welcome to SpendSense",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Stop financial leaking. Track every rupee automatically.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(40.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "What's your monthly allowance?",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = monthlyIncome,
                    onValueChange = onIncomeChange,
                    label = { Text("Amount in ₹") },
                    leadingIcon = { Text("₹", style = MaterialTheme.typography.headlineSmall) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    FeatureCard(icon = Icons.Default.TrendingUp, label = "AI Categorization")
                    FeatureCard(icon = Icons.Default.Calculate, label = "Smart Budgets")
                    FeatureCard(icon = Icons.Default.Wallet, label = "Auto Tracking")
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onNext,
                    enabled = monthlyIncome.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Continue")
                    Icon(Icons.Default.ArrowForward, null, Modifier.padding(start = 8.dp))
                }
            }
        }
    }
}

@Composable
fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(8.dp)
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(32.dp),
            tint = MaterialTheme.colorScheme.secondary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun Step2(
    budgets: List<BudgetCategory>,
    totalIncome: Double,
    onBudgetChange: (Int, Double) -> Unit,
    onComplete: () -> Unit
) {
    val totalBudget = budgets.sumOf { it.amount }
    val remaining = totalIncome - totalBudget

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Set Your Budget Categories",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "AI will auto-adjust these based on your spending patterns",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                budgets.forEachIndexed { index, budget ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = budget.icon,
                            style = MaterialTheme.typography.headlineMedium,
                            modifier = Modifier.width(48.dp)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = budget.name,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            OutlinedTextField(
                                value = if (budget.amount == 0.0) "" else budget.amount.toInt().toString(),
                                onValueChange = { value ->
                                    onBudgetChange(index, value.toDoubleOrNull() ?: 0.0)
                                },
                                leadingIcon = { Text("₹") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }

                    if (index < budgets.size - 1) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider()

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Budget", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "₹${totalBudget.toInt()}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Remaining", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "₹${remaining.toInt()}",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (remaining >= 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onComplete,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start Tracking")
                    Icon(Icons.Default.ArrowForward, null, Modifier.padding(start = 8.dp))
                }
            }
        }
    }
}
