package com.spendsense.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.spendsense.app.data.BudgetCategory
import com.spendsense.app.data.Transaction

@Composable
fun DashboardScreen(
    budgets: List<BudgetCategory>,
    transactions: List<Transaction>,
    totalIncome: Double
) {
    val totalSpent = transactions.sumOf { it.amount }
    val totalBudget = budgets.sumOf { it.amount }
    val remaining = totalIncome - totalSpent
    val leakPercentage = if (totalIncome > 0) (totalSpent / totalIncome * 100) else 0.0

    val spendingByCategory = budgets.map { budget ->
        val spent = transactions.filter { it.category == budget.name }.sumOf { it.amount }
        budget.copy(spent = spent)
    }

    val aiInsight = if (totalSpent > totalBudget * 0.8) {
        val topCategory = spendingByCategory.maxByOrNull { it.spent }
        "You're spending ${leakPercentage.toInt()}% of your allowance. AI suggests reducing ${topCategory?.name ?: "expenses"}."
    } else {
        "Great control! You've spent ${leakPercentage.toInt()}% of your allowance. Keep it up!"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Overview",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "Spent",
                    value = "₹${totalSpent.toInt()}",
                    subtitle = "${leakPercentage.toInt()}% of allowance",
                    icon = Icons.Default.TrendingDown,
                    iconTint = MaterialTheme.colorScheme.error
                )

                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "Remaining",
                    value = "₹${remaining.toInt()}",
                    subtitle = "${((remaining / totalIncome) * 100).toInt()}% left",
                    icon = Icons.Default.Wallet,
                    iconTint = if (remaining > 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                )
            }
        }

        item {
            StatCard(
                modifier = Modifier.fillMaxWidth(),
                title = "AI Tracked",
                value = "${transactions.count { it.aiParsed }}",
                subtitle = "of ${transactions.size} transactions",
                icon = Icons.Default.AutoAwesome,
                iconTint = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        if (totalSpent > totalBudget * 0.8) Icons.Default.Warning else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (totalSpent > totalBudget * 0.8) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "AI Insight",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = aiInsight,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Category Breakdown",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(spendingByCategory) { category ->
            CategoryCard(category = category)
        }
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: androidx.compose.ui.graphics.Color
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    icon,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = iconTint
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun CategoryCard(category: BudgetCategory) {
    val percentage = if (category.amount > 0) (category.spent / category.amount * 100) else 0.0
    var animatedProgress by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        animatedProgress = (percentage / 100).toFloat().coerceIn(0f, 1f)
    }

    val progress by animateFloatAsState(
        targetValue = animatedProgress,
        animationSpec = tween(durationMillis = 1000),
        label = "progress_animation"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = category.icon,
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        text = category.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "₹${category.spent.toInt()} / ₹${category.amount.toInt()}",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${percentage.toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (percentage > 100) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = when {
                    percentage > 100 -> MaterialTheme.colorScheme.error
                    percentage > 80 -> MaterialTheme.colorScheme.tertiary
                    else -> MaterialTheme.colorScheme.secondary
                },
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
