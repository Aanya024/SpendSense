# SpendSense Android - Quick Setup Guide

## 📱 What You're Getting

A complete, production-ready Android app with:
- ✅ Onboarding flow for budget setup
- ✅ Dashboard with spending analytics
- ✅ AI-powered transaction categorization (simulated)
- ✅ Predictive budgeting with forecasts
- ✅ Subscription tracker with renewal alerts
- ✅ AI chatbot for financial advice
- ✅ Beautiful dark theme (Purple/Charcoal/Teal/Rose)
- ✅ Local data persistence
- ✅ Smooth animations

## 🚀 5-Minute Setup

### Step 1: Download Android Studio
Visit: https://developer.android.com/studio
- Download Android Studio Hedgehog or later
- Install with default settings
- It will install JDK 17 automatically

### Step 2: Open Project
1. Launch Android Studio
2. Click **"Open"** (not "New Project")
3. Navigate to the `android` folder
4. Click **"OK"**

### Step 3: Wait for Sync
- Android Studio will automatically download dependencies
- You'll see a progress bar at the bottom
- First sync takes 5-10 minutes (downloads ~500MB)
- ☕ Grab a coffee!

### Step 4: Create Emulator (Optional)
If you don't have a physical device:
1. Click the **Device Manager** icon (phone icon in toolbar)
2. Click **"Create Device"**
3. Select **"Pixel 5"** or any phone
4. Click **"Next"**
5. Download **Android 14 (API 34)** system image
6. Click **"Finish"**

### Step 5: Run!
1. Click the green **Play button** ▶️ in the toolbar
2. OR press `Shift + F10` (Windows/Linux) or `Control + R` (Mac)
3. Select your device/emulator
4. Wait 30-60 seconds for build
5. App launches! 🎉

## 📂 Project Structure

```
android/
├── app/
│   ├── build.gradle.kts          ← Dependencies & Android config
│   └── src/main/
│       ├── AndroidManifest.xml   ← App permissions & entry point
│       ├── java/com/spendsense/app/
│       │   ├── MainActivity.kt           ← App entry point
│       │   ├── data/
│       │   │   └── Models.kt             ← Data classes
│       │   ├── viewmodel/
│       │   │   └── SpendSenseViewModel.kt ← State management
│       │   └── ui/
│       │       ├── SpendSenseApp.kt      ← Main app + navigation
│       │       ├── theme/
│       │       │   ├── Color.kt          ← Your custom colors
│       │       │   ├── Theme.kt          ← Material3 theme
│       │       │   └── Type.kt           ← Typography
│       │       └── screens/
│       │           ├── OnboardingScreen.kt
│       │           ├── DashboardScreen.kt
│       │           ├── TransactionListScreen.kt
│       │           ├── SubscriptionTrackerScreen.kt
│       │           ├── ChatbotScreen.kt
│       │           └── PredictiveBudgetScreen.kt
│       └── res/
│           └── values/
│               ├── strings.xml
│               ├── colors.xml
│               └── themes.xml
├── build.gradle.kts              ← Root build file
├── settings.gradle.kts           ← Project settings
└── gradle.properties             ← Gradle configuration
```

## 🎨 Key Technologies Used

| Technology | Purpose |
|------------|---------|
| **Kotlin** | Modern Android programming language |
| **Jetpack Compose** | Declarative UI framework (like React) |
| **Material Design 3** | Google's latest design system |
| **StateFlow** | Reactive state management |
| **ViewModel** | Lifecycle-aware state holder |
| **SharedPreferences** | Local data storage |
| **Gson** | JSON serialization |
| **YCharts** | Compose-native charts |

## 🎯 How to Test the App

### First Launch
1. **Onboarding appears**
   - Enter monthly allowance: `5000`
   - Set budgets (e.g., Food: 1500, Transport: 500, etc.)
   - Click "Start Tracking"

2. **You'll see sample data**
   - 8 pre-loaded transactions
   - 4 subscriptions (3 active, 1 paused)

### Test Features

1. **Add Random Transaction**
   - Tap the **+ FAB** (Floating Action Button)
   - Watch a new transaction appear
   - See budget percentages update

2. **Navigate Screens**
   - Open drawer (☰ menu)
   - Try all 5 screens:
     - Dashboard
     - AI Forecast
     - Transactions
     - Subscriptions
     - AI Chat

3. **Chat with AI**
   - Ask: "How much have I spent?"
   - Ask: "Give me budget advice"
   - Ask: "Show recent transactions"

4. **Manage Subscriptions**
   - Pause a subscription
   - Resume it
   - Cancel one

5. **Check Predictions**
   - Go to "AI Forecast"
   - See predicted month-end total
   - Check category forecasts

## 🔧 Common Issues & Fixes

### "Gradle Sync Failed"
```bash
# In Android Studio Terminal (bottom panel):
./gradlew clean build --refresh-dependencies
```

### "SDK Not Found"
1. File → Project Structure → SDK Location
2. Set Android SDK path
3. Install SDK 34 via SDK Manager

### "JDK Error"
1. File → Project Structure → SDK Location
2. Gradle JDK → Select "jbr-17" (comes with Android Studio)

### "Emulator Won't Start"
- Check BIOS virtualization is enabled
- Install "Intel HAXM" or "Android Emulator Hypervisor"

### "Build Takes Forever"
- First build downloads all dependencies (5-10 min)
- Subsequent builds are much faster (30-60 sec)

## 📱 Running on Physical Device

1. **Enable Developer Options**
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
   - Developer Options unlocked!

2. **Enable USB Debugging**
   - Settings → Developer Options
   - Turn ON "USB Debugging"

3. **Connect & Run**
   - Connect phone via USB
   - Allow debugging prompt on phone
   - Select your device in Android Studio
   - Click Run ▶️

## 🎓 Code Walkthrough

### Want to Understand the Code?

**Start here:**
1. `MainActivity.kt` - Entry point
2. `SpendSenseApp.kt` - Navigation & main structure
3. `OnboardingScreen.kt` - Simplest screen to understand
4. `SpendSenseViewModel.kt` - State management
5. `DashboardScreen.kt` - More complex UI

**Key Concepts:**
- `@Composable` = UI component function
- `remember { }` = Local state
- `LaunchedEffect { }` = Side effects
- `collectAsState()` = Observe ViewModel state

### Customization Ideas

**Change Colors:**
- Edit `ui/theme/Color.kt`

**Add New Category:**
- Edit `OnboardingScreen.kt` line 28
- Update `generateBotResponse()` in ChatbotScreen

**Modify Sample Data:**
- Edit `loadSampleData()` in `SpendSenseViewModel.kt`

## 🚀 Next Steps

### To Make It Production-Ready:

1. **Add Real SMS Parsing**
   ```kotlin
   // Add to AndroidManifest.xml:
   <uses-permission android:name="android.permission.RECEIVE_SMS" />

   // Create SMSReceiver.kt
   // Parse SMS and extract vendor, amount
   ```

2. **Integrate Real AI API**
   ```kotlin
   // Add Retrofit for API calls
   // Call OpenAI/Claude API for categorization
   ```

3. **Add Cloud Sync**
   - Use Firebase Firestore or Supabase
   - Implement user authentication
   - Sync across devices

4. **Add Notifications**
   ```kotlin
   // Schedule budget alert notifications
   // Alert before subscription renewal
   ```

## 📚 Learning Resources

- **Jetpack Compose**: https://developer.android.com/jetpack/compose/tutorial
- **Material Design 3**: https://m3.material.io/
- **Android Basics**: https://developer.android.com/courses/android-basics-compose/course
- **Kotlin**: https://kotlinlang.org/docs/getting-started.html

## 💡 Tips

- Use **Live Preview** in Android Studio to see UI changes instantly
- Enable **Hot Reload** for faster development
- Check **Logcat** (bottom panel) for debugging
- Use **Layout Inspector** to debug UI issues

## ✨ That's It!

You now have a fully functional Android expense tracking app with AI features, matching the exact design and functionality of the web version!

**Questions?**
- Check comments in the code
- Read the main README.md
- Explore Android documentation

**Happy Coding! 🚀**
