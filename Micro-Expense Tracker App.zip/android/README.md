# SpendSense - Android Application

**Stop Financial Leaking. Track Every Rupee Automatically.**

SpendSense is a native Android application designed for students to manage their micro-expenses (canteen meals, stationary, local travel) and prevent "financial leaking" - where monthly allowances disappear without knowing where they went.

## Features

### 1. **AI-Powered Transaction Parsing & Categorization**
- Automatically detects transactions from SMS/push notifications
- AI categorizes expenses into Food, Transport, Entertainment, Shopping, and Other
- Displays raw notification text for transparency

### 2. **Predictive Budgeting**
- Analyzes spending patterns to forecast month-end totals
- Suggests safe daily spending limits
- Predicts category-wise expenditure based on current trends

### 3. **AI Chatbot Assistant**
- Natural language interface to query spending data
- Provides personalized budget advice
- Answers questions about transactions and savings

### 4. **Smart Budget Alerts**
- Set monthly budgets for each category during onboarding
- Receives alerts when nearing 80-90% of budget limits
- AI automatically adjusts next month's budgets based on actual spending patterns

### 5. **Subscription Tracker**
- Tracks recurring subscriptions (Netflix, Spotify, Amazon Prime, etc.)
- Sends alerts 7 days before renewal
- Options to pause or cancel subscriptions directly from the app

## Design

The app uses a modern dark theme with carefully chosen colors:
- **Primary**: `#BB86FC` (Soft Purple) - Modern, techy, non-threatening
- **Background**: `#121212` (Deep Charcoal) - High contrast for data visualization
- **Surface**: `#1E1E1E` (Lighter Grey) - For cards and elevated surfaces
- **Secondary**: `#03DAC6` (Teal) - For positive indicators and "good" statuses
- **Destructive**: `#CF6679` (Muted Rose) - Soft way to show alerts without panic

## Technology Stack

- **Language**: Kotlin
- **UI Framework**: Jetpack Compose (declarative UI, similar to React)
- **Architecture**: MVVM (Model-View-ViewModel)
- **State Management**: StateFlow & ViewModel
- **Local Storage**: SharedPreferences with Gson for JSON serialization
- **Charts**: YCharts for Compose
- **Animations**: Compose Animation APIs
- **Navigation**: Compose Navigation

## Project Structure

```
android/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/spendsense/app/
│   │       │   ├── data/
│   │       │   │   └── Models.kt                 # Data classes
│   │       │   ├── ui/
│   │       │   │   ├── screens/
│   │       │   │   │   ├── OnboardingScreen.kt   # Budget setup flow
│   │       │   │   │   ├── DashboardScreen.kt    # Main overview
│   │       │   │   │   ├── TransactionListScreen.kt
│   │       │   │   │   ├── SubscriptionTrackerScreen.kt
│   │       │   │   │   ├── ChatbotScreen.kt      # AI assistant
│   │       │   │   │   └── PredictiveBudgetScreen.kt
│   │       │   │   ├── theme/
│   │       │   │   │   ├── Color.kt              # Color definitions
│   │       │   │   │   ├── Theme.kt              # Material3 theme
│   │       │   │   │   └── Type.kt               # Typography
│   │       │   │   └── SpendSenseApp.kt          # Main app composable
│   │       │   ├── viewmodel/
│   │       │   │   └── SpendSenseViewModel.kt    # State management
│   │       │   └── MainActivity.kt               # Entry point
│   │       ├── res/
│   │       │   └── values/
│   │       │       ├── strings.xml
│   │       │       ├── colors.xml
│   │       │       └── themes.xml
│   │       └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Setup Instructions

### Prerequisites

1. **Android Studio** - Download from [developer.android.com](https://developer.android.com/studio)
   - Recommended version: Android Studio Hedgehog (2023.1.1) or later
   - Install with Android SDK 34

2. **Java Development Kit (JDK)** - JDK 17 is required
   - Usually comes bundled with Android Studio

### Installation Steps

1. **Open Android Studio**

2. **Import Project**
   - Click "Open an Existing Project"
   - Navigate to the `android` folder
   - Click "OK"

3. **Sync Gradle**
   - Android Studio will automatically start syncing Gradle
   - If not, click "File" → "Sync Project with Gradle Files"
   - Wait for all dependencies to download (may take 5-10 minutes on first run)

4. **Connect Device or Emulator**

   **Option A: Physical Device**
   - Enable Developer Options on your Android device
   - Enable USB Debugging
   - Connect via USB

   **Option B: Emulator**
   - Click "Device Manager" in Android Studio
   - Click "Create Device"
   - Select a phone (e.g., Pixel 5)
   - Choose Android 14 (API 34) system image
   - Click "Finish"

5. **Run the App**
   - Click the green "Run" button (▶️) in the toolbar
   - OR press `Shift + F10` (Windows/Linux) or `Control + R` (Mac)
   - Select your device/emulator
   - Wait for the app to build and install

### Troubleshooting

#### Gradle Sync Failed
```bash
# In Android Studio terminal:
./gradlew clean build --refresh-dependencies
```

#### SDK Not Found
- Go to "File" → "Project Structure" → "SDK Location"
- Ensure Android SDK path is set correctly
- Install SDK 34 if missing via SDK Manager

#### Build Failed
- Check that JDK 17 is being used
- "File" → "Project Structure" → "SDK Location" → "Gradle JDK"

#### Emulator Won't Start
- Ensure virtualization is enabled in BIOS
- Update Intel HAXM or install Android Emulator Hypervisor Driver

## How to Use

### First Launch (Onboarding)

1. **Step 1: Set Monthly Allowance**
   - Enter your monthly allowance (e.g., 5000)
   - Click "Continue"

2. **Step 2: Set Category Budgets**
   - Allocate budget for each category:
     - 🍔 Food
     - 🚌 Transport
     - 🎬 Entertainment
     - 🛍️ Shopping
     - 📦 Other
   - View remaining budget
   - Click "Start Tracking"

### Main Features

1. **Dashboard**
   - View total spent, remaining balance, and AI-tracked transactions
   - See AI insights and recommendations
   - Check 7-day spending trends
   - Monitor budget vs spent for each category

2. **AI Forecast**
   - View predicted month-end spending
   - See daily average and days remaining
   - Get AI recommendations for safe daily limits
   - Check category-wise forecasts

3. **Transactions**
   - View all transactions grouped by date
   - See AI-parsed transactions with sparkle icon
   - View raw notification text for AI-parsed items

4. **Subscriptions**
   - Track active and paused subscriptions
   - Get alerts for subscriptions expiring within 7 days
   - Pause, resume, or cancel subscriptions

5. **AI Chat**
   - Ask questions like:
     - "How much have I spent?"
     - "Show my recent transactions"
     - "Give me budget advice"
     - "How am I doing with food expenses?"
   - Get personalized financial insights

### Testing

Click the **Floating Action Button (➕)** to simulate random transactions and see the app in action!

## Data Persistence

- All data is saved locally using **SharedPreferences**
- Data persists across app restarts
- No internet connection required
- No external database needed

## Future Enhancements

To make this app production-ready, consider:

1. **Real SMS/Notification Parsing**
   - Request SMS and Notification permissions
   - Implement BroadcastReceiver for SMS
   - Use NotificationListenerService for app notifications
   - Integrate actual AI API (OpenAI, Anthropic Claude, etc.)

2. **Cloud Sync**
   - Integrate Firebase or Supabase
   - Sync data across devices
   - Implement user authentication

3. **Advanced AI Features**
   - Real ML models for spending predictions
   - Anomaly detection for unusual expenses
   - Smart recommendations based on similar users

4. **Additional Features**
   - Export data to CSV/PDF
   - Expense splitting with friends
   - Receipt scanning with OCR
   - Integration with UPI apps

## Contributing

This is a student project demonstrating:
- Modern Android development with Jetpack Compose
- MVVM architecture pattern
- State management with StateFlow
- Material Design 3 theming
- Responsive UI design

## License

MIT License - Feel free to use this project for learning and personal use.

## Support

For issues or questions:
- Check the code comments in each file
- Review Android documentation: [developer.android.com](https://developer.android.com)
- Jetpack Compose documentation: [developer.android.com/jetpack/compose](https://developer.android.com/jetpack/compose)

---

**Built with ❤️ for students who want to stop financial leaking!**
